state = ['main',1,0,0,0,0]
//state = ['play',0,0,0,0,0]//#########REMOVE THIS!##############
zoomout = 1
lookup = [0,0]
pos = [[-350,-175],[0,-175],[350,-175],[-350,175],[0,175],[350,175]]
tallpos = [[-350,-525],[0,-525],[350,-525],[-350,525],[0,525],[350,525]]
practice = [0,0]
instanttrans = -1
mb = 0
keys = []
pkeys = []
temp = null
temp2 = null
temp3 = null
fade = 0
turnx = 0
turny = 0
page = 0
pagecord = [0,0,0,-1]
version = '1.10.2'
// -262.5  -87.5 87.5    262.5
//      -175         175
alldds = [['d battery',''],['li cell',''],['aa batteries',''],['aa batteries','1'],['gamecube port',''],['midi port',''],['parallel port',''],['none',''],['none','']]
size1dds = ['aa batteries','gamecube port','midi port','none']
size1dd = [['aa batteries',''],['aa batteries','1'],['gamecube port',''],['midi port',''],['none','']]

batteries = ['aa batteries','d battery','li cell']
bamphours = {
	'aa batteries':6,
	'aa batteries1':3,
	'd battery':8,
	'li cell':2.6,
}

bombs = [
	['Playing it Straight',['breakers','thebutton','keypad'],[],3,300,'Make sure your experts\nhave the manual and are\nready to help.',1],
	['Time Crunch',[],['breakers','thebutton','keypad'],3,180,'3 Minutes, 3 Modules.\nThink you can do it?',1],
	['Full House',[],['breakers','thebutton','keypad'],5,300,"This one's all booked.",1],
	['Some\'a the Old, Some\'a the New',['fnf','whosfirst'],['breakers','thebutton','keypad'],4,300,'Some new modules to chew on!\n(do not chew on bombs)',1],
	['Upgrades, People',['thebutton2','capacitors'],['breakers','thebutton','keypad','fnf'],4,360,'What could possibly\nbe better than these?',1],
	['Complex Cadet',['thebutton2','capacitors','fnf','whosfirst'],['thebutton2','capacitors','fnf','whosfirst'],5,420,'I hope you got\nused to these new\nmodules!',1],
	['Lightning Round',[],['breakers','thebutton','keypad'],2,30,'Prepare Yourself...\nGet ready to solve.',1],
	['Two Bits',['twobits',['breakers','thebutton','keypad']],['breakers','thebutton','keypad','fnf'],3,240,'Better get used to new modules fast.\n(Though, this one\'s kinda slow...)',1],
	['Juggling Act',['twobits','twobits','twobits'],[],3,150,'Human brains weren\'t meant to multitask...\nBut you can try your best!',1],
	['Sadist\'s Comedy Routine',['thebutton2','whosfirst'],['thebutton2','whosfirst'],4,240,'Maybe it\'d be funny if it\nwasn\'t on a bomb.',1],
	['Midterm',['twobits','concheck',['thebutton2','capacitors','whosfirst']],['breakers','keypad','fnf'],5,270,'Let\'s see what you got!',1],
	['Cookie',['oven',['thebutton2','capacitors','whosfirst']],['fnf','breakers','keypad','thebutton'],4,300,'heehoo cookie',1],
	['Cook',['oven','thebutton','thebutton'],['thebutton2','twobits'],4,180,'Don\'t get too preoccupied.',1],
	['Unnamed 0',['oven','concheck',['twobits','thebutton2','capacitors','whosfirst']],['fnf','breakers','keypad','thebutton','switches'],5,180,'bruh\nthese bomb names are wack',1],
	['Switch Case',['concheck','switches',['oven','whosfirst'],['thebutton2','whosfirst']],['breakers','keypad','thebutton','switches'],5,240,'It\'s getting harder!',1],
	['Checks Connected',['concheck','concheck','concheck','concheck','concheck'],[],5,150,'Wait... shouldn\'t it be\n"Connections Checked"?',1],
	['Juggling Act II',['twobits',['twobits','oven'],'oven','thebutton2'],[],4,240,'Your best isn\'t enough.\nTry your best-er.',1],
	['Scatter Platter',[['twobits','oven'],['thebutton2','whosfirst','capacitors','keypadloops'],'keypad',['breakers','thebutton'],['concheck','switches']],[],5,210,'It\'s just a lot.',1],
	['All Grown Up',['keypadloops','thebutton2','capacitors'],[],3,300,'Look how far we\'ve come.',1],
	['Paka cai xikatseti...',['oven','thebutton2','keypadloops','keypadloops'],[],4,420,'All things...',1],
	['...latkiea zon tuea moi.',['whosfirst','password','keypadloops','password'],[],4,330,'...shall burn.',1],
	['Tall Order',['breakers','capacitors','keypadloops','keypad'],['breakers','keypad','thebutton'],7,300,'Use the W and S\nkeys to look\nup and down, or scroll.',2],
	['Fuller House',['breakers','capacitors','keypadloops','keypad','whosfirst','twobits','fnf','concheck'],['breakers','keypad','thebutton'],11,660,'Again, use the W and S\nkeys to look\nup and down, or scroll.',2],
	['Call and Response',['keypadloops','whosfirst','twobits','fnf','thebutton2'],['breakers','keypad','thebutton'],7,420,'Response from call.',2],
	['Unnamed 1',['password','fnf','switches','password'],['concheck','oven','twobits'],5,240,'the long awaited\nsequel',1],
	['Hot Seat',[],['password','thebutton2','whosfirst'],1,60,'Which module is\nhere?',1],
	['Hellish Module',['topsyturvy'],[],1,300,'Good luck.',1],
]

function mousePressed() {
	mb = 1
}
function mouseReleased() {
	mb = 0
}
function keyPressed() {
	if (!keys.includes(keyCode)) {
		keys.push(keyCode)
	}
	///* this is also cool##############################################################
	if (compareValues(keys,[49,50,51,53])) {
		state = ['play',0,0,0,0,0]
		level = new Game(-350,-175,0,1000,[new Breakers(350,-175)])
		for (let i of level.modules) {i.setup()}
	}
	//*/ this is also cool##############################################################
}
function keyReleased() {
	let exttemp = keys
	keys = []
	for (let i of [37,38,39,40]) {
		if (exttemp.includes(i) && keyCode != i) {
			keys.push(i)
		}
	}
}
function mouseWheel(event) {
	let exttemp = keys
	keys = []
	for (let i of [37,38,39,40]) {
		if (exttemp.includes(i) && keyCode != i) {
			keys.push(i)
		}
	}
}
function mouseWheel(event) {
	if (state[0] == 'play' && level.size > 1) 
		lookup[1] += event.delta;
}

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	frameRate(60);
	level = null
	randlist = []
	for (let i = 0; i < bombs.length/7; i++) {
		randlist.push(random()*24-12)
	}
	//level = new Game(-350,-175,0,300,[new Password(0,-175)])//#########REMOVE THIS!###########
	//for (let i of level.modules) {i.setup()}//#########REMOVE THIS!###########################
}
function setupGame(bombnum,prac=false) {
	let exttemp = []
	if (prac == false) {
		for (let i of bombs[bombnum][1]) {
			if (typeof i == 'string') {
				exttemp.push(i)
			}
			else {
				let chosen = random(i)
				if (typeof i == 'string') {
					exttemp.push(chosen)
				}
				else {
					exttemp = concat(exttemp,chosen)
				}
			}
		}
		while (exttemp.length < bombs[bombnum][3]) {
			exttemp.push(random(bombs[bombnum][2]))
		}
	}
	else {
		exttemp.push(['breakers','thebutton','keypad','thebutton2','capacitors','fnf','twobits','whosfirst','oven','concheck','switches','keypadloops','password','topsyturvy'][bombnum])
		exttemp.push('control')
	}
	let exttemp2 = []
	let exttemp3;
	places = structuredClone(pos)
	let exttemp4 = floor(random()*places.length)
	exttemp4 = places.splice(exttemp4,1)[0]
	if (bombs[bombnum][6] == 2) {
		places = concat(places, tallpos)
	}
	for (let i of exttemp) {
		exttemp3 = floor(random()*places.length)
		exttemp3 = places.splice(exttemp3,1)[0]
		if (i == 'breakers') {
			exttemp2.push(new Breakers(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'thebutton') {
			exttemp2.push(new TheButton(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'keypad') {
			exttemp2.push(new Keypad(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'thebutton2') {
			exttemp2.push(new TheButton2(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'capacitors') {
			exttemp2.push(new Capacitors(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'fnf') {
			exttemp2.push(new Fnf(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'twobits') {
			exttemp2.push(new TwoBits(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'whosfirst') {
			exttemp2.push(new WhosFirst(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'oven') {
			exttemp2.push(new Oven(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'concheck') {
			exttemp2.push(new ConCheck(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'switches') {
			exttemp2.push(new Switches(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'keypadloops') {
			exttemp2.push(new KeypadLoops(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'password') {
			exttemp2.push(new Password(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'topsyturvy') {
			exttemp2.push(new TopsyTurvy(exttemp3[0],exttemp3[1]))
		}
		else if (i == 'control') {
			exttemp2.push(new Control(exttemp3[0],exttemp3[1]))
		}
		else {
			exttemp2.push(new TestM(exttemp3[0],exttemp3[1],false,0,i))
		}
	}
	if (prac == false) {
		level = new Game(exttemp4[0],exttemp4[1],0,bombs[bombnum][4],exttemp2,bombs[bombnum][6])
	}
	else {
		level = new Game(exttemp4[0],exttemp4[1],0,0,exttemp2,1)
	}
}

function bigCodeBlockFolder() {
		textAlign(CENTER,CENTER)
		push()
		fill(225,198,153)
		translate(-350,0)
		scale(max(state[1],-1),1)
		rect(350,0,700,800)
		beginShape()
		vertex(699,-350)
		vertex(730,-325)
		vertex(730,-225)
		vertex(699,-200)
		endShape()
		if (state[1] > 0) {
			fill(0)
			textSize(100)
			textFont('courier new')
			text('Keep\nProcessing\nand Nobody\nExplodes',350,-100)
			textSize(16)
			push()
			rotate(PI/2)
			fill(185,158,113)
			text('Click here',-275,-715)
			pop()
			textSize(100)
			textFont('arial')
			push()
			stroke(235,0,0)
			rotate(0.14)
			noFill()
			rect(350,250,140,140)
			rect(350,250,120,120)
			fill(235,0,0)
			text('P*',350,250)
			rotate(-0.14)
			noStroke()
			textSize(16)
			fill(185,158,113)
			text('Ver '+version,55,375)
			pop()
		}
		else {
			fill(240,240,220)
			rect(350,0,650,750)
			scale(-1,1)
			textSize(40)
			fill(0)
			textFont('courier new')
			text('Basic Info:',-350,-270)
			textSize(30)
			text('-----------------------------\nDefuse all modules on a\nbomb to defuse the bomb.',-350,-180)
			text('-----------------------------\nUse arrow keys to check\nthe casing of the bomb.',-350,-60)
			text('-----------------------------\nThe Expert should\nhave the bomb defusal\nmanual open.',-350,80)
			text('-----------------------------\nRunning out of time or\ngetting three strikes\nexplodes the bomb.',-350,230)
		}
		pop()
}

function draw() {
	cursor(ARROW)
	rectMode(CENTER)
	background(100);
	if (mb > 0) {
		mb += 1
	}
	push()
	translate(windowWidth/2,windowHeight/2)
	if (state[0].substr(0,4) == 'play') {
		textFont('arial')
		textAlign(LEFT,CENTER)
		if (keys.includes(32)) {//space?
			turnx = exphone(turnx,0,3,0.001)
			turny = exphone(turny,0,3,0.001)
		}
		else if (keys.includes(37)) {//left
			if (turny == 0) {
				turnx = exphone(turnx,-0.5,10,0.001)
			}
			else {
				turny = exphone(turny,0,3,0.01)
			}
		}
		else if (keys.includes(39)) {//right
			if (turny == 0) {
				turnx = exphone(turnx,0.5,10,0.001)
			}
			else {
				turny = exphone(turny,0,3,0.01)
			}
		}
		else if (keys.includes(38)) {//up
			if (turnx == 0) {
				turny = exphone(turny,-0.5,10,0.001)
			}
			else {
				turnx = exphone(turnx,0,3,0.01)
			}
		}
		else if (keys.includes(40)) {//down
			if (turnx == 0) {
				turny = exphone(turny,0.5,10,0.001)
			}
			else {
				turnx = exphone(turnx,0,3,0.01)
			}
		}
		else {
			turnx = exphone(turnx,0,10,0.001)
			turny = exphone(turny,0,10,0.001)
		}
		if (level.size > 1) {
			if (keys.includes(87) && !pkeys.includes(87)) {
				lookup[1] += 175/2
			}
			if (keys.includes(83) && !pkeys.includes(83)) {
				lookup[1] -= 175/2
			}
			lookup[1] = max(350-350*level.size,min(-350+350*level.size,lookup[1]))
			lookup[0] = exphone(lookup[0],lookup[1],5,0.001)
			translate(0,lookup[0])
		}
		scale(1-abs(turnx),1-abs(turny))
		translate(1000*turnx,600*turny)
		if (state[2] == 0) {
			switch (level.fails) {
				case 0:
					level.time -= 1/60; break;
				case 1:
					level.time -= 1/50; break;
				case 2:
					level.time -= 0.024; break;
			}
		}
		else {
			level.time += 1/60
		}
		fill(170)
		rectMode(CENTER)
		rect(0,0,1050,700*level.size)
		level.drawTimer()
		level.tick()
		for (var self of level.modules) {
			self.drawThis()
			self.tick()
			self.final()
		}
		if (turnx < 0) {
			push()
			rectMode(CORNER)
			translate(525,-350)
			scale(abs(turnx),1)
			fill(130)
			rect(0,350-350*level.size,1000,700*level.size)
			rectMode(CENTER)
			translate(500,87.5)//doodads
			for (var rds of level.rightdds) {
				doodad(rds[0][0],0,rds[1],rds[0][1])
			}
			pop()
		}
		else if (turnx > 0) {
			push()
			rectMode(CORNER)
			translate(-525,-350)
			scale(abs(turnx),1)
			fill(130)
			rect(0,350-350*level.size,-1000,700*level.size)
			rectMode(CENTER)
			translate(-500,87.5)//doodads
			for (var lds of level.leftdds) {
				doodad(lds[0][0],0,lds[1],lds[0][1])
			}
			pop()
		}
		else if (turny > 0) {
			push()
			rectMode(CORNER)
			translate(-525,-350*level.size)
			scale(1,abs(turny))
			fill(130)
			rect(0,0,1050,-1000)
			rectMode(CENTER)
			translate(87.5,-500)//doodads
			rotate(PI/-2)
			for (var uds of level.updds) {
				doodad(uds[0][0],0,uds[1],uds[0][1])
			}
			pop()
		}
		else if (turny < 0) {
			push()
			rectMode(CORNER)
			translate(-525,350*level.size)
			scale(1,abs(turny))
			fill(130)
			rect(0,0,1050,1000)
			rectMode(CENTER)
			translate(87.5,500)//doodads
			rotate(PI/-2)
			for (var dds of level.downdds) {
				doodad(dds[0][0],0,dds[1],dds[0][1])
			}
			pop()
		}
	}
	else if (state[0].substr(0,4) == 'main') {
		rectMode(CENTER)
		
		push()
		translate(500,0)
		let exttemp = (1-zoomout)
		rotate(PI/4+exttemp*PI)
		for (let i = 0; i < 4; i++) {
			rotate(PI/2)
			strokeWeight(10)
			stroke(120)
			line(20,0,exttemp*50+50,0)
			line(exttemp*50+50,0,exttemp*50+50-15,-15)
			line(exttemp*50+50,0,exttemp*50+50-15,15)
		}
		pop()
		if (relativeMouseOn(0,0,500,0,100,100) && practice[0] <= 30) {
			cursor(MOVE)
			zoomout = exphone(zoomout,0.5,10,0.001)
			if (keys.includes(32)) {
				zoomout = exphone(zoomout,0.5,3,0.001)
			}
		}
		else {
			zoomout = exphone(zoomout,1,10,0.001)
			if (keys.includes(32)) {
				zoomout = exphone(zoomout,1,3,0.001)
			}
		}
		scale(zoomout)
		
		push()
		textAlign(CENTER,CENTER)
		textFont('courier new')
		fill(225,198,153)
		translate(-350+practice[0],120)
		rect(350,-120,700,800)
		beginShape()
		vertex(699,-350)
		vertex(730,-325)
		vertex(730,-225)
		vertex(699,-200)
		endShape()
		textSize(16)
		push()
		rotate(PI/2)
		fill(185,158,113)
		text('Practice',-275,-715)
		pop()
		fill(250,250,240)
		rect(350,-120,650,750)
		fill(50,50,155)
		textSize(20)
		textAlign(CENTER,CENTER)
		textFont('calibri')
		temp2 = ['breakers','thebutton','keypad','thebutton2','capacitors','fnf','twobits','whosfirst','oven','concheck','switches','keypadloops','password','topsyturvy']
		for (let i = 0; i < temp2.length; i++) {
			if (bombs[i] == undefined) {
				continue
			}
			temp = (i-9)*50
			text('---------------',590,temp-25)
			text(temp2[i],590,temp)
		}
		text('---------------',590,temp+25)
		pop()
		
		fill(225,198,153)
		rect(0,0,700,800)
		
		if (state[1] <= 0) {
			bigCodeBlockFolder()
		}
		
		let did = false
		let clicked = false
		for (let pages = floor((bombs.length)/7); pages > -1; pages--) {//might cause bugs!
			push()
			if (pagecord[3] == 1) {
				if (page-1 > pages) {
					translate(-800,-150)
					rotate(randlist[pages]/100)
				}
				else if (page > pages) {
					translate(pagecord[0],pagecord[1])
					rotate(pagecord[2]/100)
				}
			}
			if (pagecord[3] == -1) {
				if (page > pages) {
					translate(-800,-150)
					rotate(randlist[pages]/100)
				}
				else if (page == pages) {
					translate(pagecord[0],pagecord[1])
					rotate(pagecord[2]/100)
				}
			}
			fill(250,250,240)
			rect(0,0,650,750)
			fill(50,50,155)
			textSize(40)
			textAlign(CENTER,CENTER)
			textFont('calibri')
			for (let i = pages*7; i < pages*7+7; i++) {
				if (bombs[i] == undefined) {
					continue
				}
				temp = ((i%7)-3)*100
				text('-------------------------------',0,temp-50)
				text(bombs[i][0],0,temp)
			}
			text('-------------------------------',0,temp+50)
			if (pages != 0) {
				text('<<<',-250,350)
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,-250,350,0,0,60,30) && pages == page) {
					cursor(HAND)
					if (mb == 2 && clicked == false) {
						page--
						pagecord[0] = -800
						pagecord[1] = -150
						pagecord[2] = randlist[page]
						pagecord[3] = -1
						clicked = true
					}
				}
			}
			if (pages != floor((bombs.length-1)/7) || did) {
				text('>>>',250,350)
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,250,350,0,0,60,30) && pages == page) {
					cursor(HAND)
					if (mb == 2) {
						page++
						pagecord[0] = 0
						pagecord[1] = 0
						pagecord[2] = 0
						pagecord[3] = 1
					}
				}
			}
			pop()
		}
		if (pagecord[3] == 1) {
			pagecord[0] = exphone(pagecord[0],-800,10,0.001)
			pagecord[1] = exphone(pagecord[1],-150,10,0.001)
			pagecord[2] = exphone(pagecord[2],randlist[page-1],20,0.001)
			if (keys.includes(32)) {
				pagecord[0] = exphone(pagecord[0],-800,3,0.001)
				pagecord[1] = exphone(pagecord[1],-150,3,0.001)
				pagecord[2] = exphone(pagecord[2],randlist[page-1],4,0.001)
			}
		}
		else if (pagecord[3] == -1) {
			pagecord[0] = exphone(pagecord[0],0,10,0.001)
			pagecord[1] = exphone(pagecord[1],0,10,0.001)
			pagecord[2] = exphone(pagecord[2],0,20,0.001)
			if (keys.includes(32)) {
				pagecord[0] = exphone(pagecord[0],0,3,0.001)
				pagecord[1] = exphone(pagecord[1],0,3,0.001)
				pagecord[2] = exphone(pagecord[2],0,4,0.001)
			}
		}
		
		if (state[1] > 0) {
			bigCodeBlockFolder()
		}
		
		if (state[0] == 'main#menu') {
			state[1] = exphone(state[1],-1,10,0.001)
			if (keys.includes(32)) {
				state[1] = exphone(state[1],-1,3,0.001)
			}
			if (state[1] == -1) {
				state[0] = 'mainmenu'
			}
		}
		else if (state[0] == 'main#practice') {
			practice[0] = exphone(practice[0],practice[1],10,0.001)
			if (keys.includes(32)) {
				practice[0] = exphone(practice[0],practice[1],3,0.001)
			}
			if (practice[0] == practice[1]) {
				if (practice[0] == 200) {
					state[0] = 'mainpractice'
				}
				else {
					state[0] = 'mainmenu'
				}
			}
		}
		else if (state[0].substr(0,8) == 'mainmenu') {
			textSize(40)
			for (let i = page*7; i < page*7+7; i++) {
				if (bombs[i] == undefined) {
					continue
				}
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,0,((i%7)-3)*100,0,0,textWidth(bombs[i][0]),40)) {
					cursor(HAND)
					if (mb == 2) {
						state[0] = 'main-s#' + i.toString()
						state[2] = random()*600-300
						state[3] = 800
						state[5] = random()*24-12
					}
				}
			}
		}
		else if (state[0].substr(0,5) == 'main-') {
			push()
			translate(state[2],state[3])
			rotate(state[4]/100)
			fill(250,250,240)
			rect(0,0,650,750)
			rect(0,-300,600,70)
			rect(0,-50,600,430)
			rect(0,100,600,200)
			fill(0)
			textSize(40)
			textFont('calibri')
			temp = parseInt(state[0].split('#')[1])
			text(bombs[temp][0],0,-300)//identifier
			textSize(30)
			text(bombs[temp][5],0,-200)
			text(`Modules: ${bombs[temp][3]}    Time: ${floor(bombs[temp][4]/60)}:${(bombs[temp][4]%60).toString().padStart(2,'0')}`,0,50)
			text('Back',-250,170)
			text('Start',250,170)
			pop()
			if (state[2] == 0 && state[3] == 0) {
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,-250,170,100,100,0,0)) {
					cursor(HAND)
					if (mb == 2) {
						state[0] = 'main-b#' + temp.toString()
					}
				}
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,250,170,100,100,0,0)) {
					cursor(HAND)
					if (mb == 2) {
						state[0] = 'main-g#' + temp.toString()
					}
				}
			}
			if (state[0].substr(0,6) == 'main-s') {
				state[2] = exphone(state[2],0,10,0.01)
				state[3] = exphone(state[3],0,10,0.01)
				state[4] = exphone(state[4],state[5],15,0.01)
				if (keys.includes(32)) {
					state[2] = exphone(state[2],0,3,0.01)
					state[3] = exphone(state[3],0,3,0.01)
					state[4] = exphone(state[4],state[5],4,0.01)
				}
			}
			else if (state[0].substr(0,6) == 'main-b') {
				state[3] = exphone(state[3],1200,10,10)
				if (keys.includes(32)) {
					state[3] = exphone(state[3],1200,3,10)
				}
				if (state[3] == 1200) {
					state[0] = 'mainmenu'
				}
			}
			else if (state[0].substr(0,6) == 'main-g') {
				fade += 15
				fill(0,fade)
				rect(0,0,3000,2000)
				if (fade > 1000) {
					setupGame(temp)
					temp = state[0].split('#')[1]
					state = ['almost',200,temp,0,0,0]
				}
			}
		}
		else if (state[0].substr(0,7) == 'mainwin') {
			push()
			translate(state[2],state[3])
			rotate(state[4]/100)
			fill(250,250,240)
			rect(0,0,650,750)
			rect(0,-300,600,70)
			rect(0,-50,600,430)
			rect(0,100,600,200)
			fill(0)
			textFont('calibri')
			textSize(40)
			temp = parseInt(state[0].split('#')[1])
			if (state[2] == 0) {text(bombs[temp][0],0,-300)}//identifier
			else {text('Practice',0,-300)}
			textSize(30)
			if (state[2] == 0) {text(bombs[temp][5],0,-200)}
			else {text('cool',0,-200)}
			text(`Time Remaining: ${floor(level.time/60)}:${(floor(level.time)%60).toString().padStart(2,'0')}`,0,100)
			text('Back',-250,230)
			push()
			stroke(0,0,200)
			noFill()
			rect(0,-70,300,100)
			rect(0,-70,280,80)
			fill(0,0,200)
			textSize(55)
			text('Defused',0,-70)
			if (fade > 0) {
				fade -= 15
			}
			pop()
			pop()
			fill(0,fade)
		  rect(0,0,3000,2000)
			if (state[3] == 0) {
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,-250,230,100,100,0,0)) {
					cursor(HAND)
					if (mb == 2) {
						state[0] = 'mainwin-b#' + temp.toString()
					}
				}
			}
			if (state[0].substr(0,9) == 'mainwin-b') {
				state[3] = exphone(state[3],1200,10,10)
				if (keys.includes(32)) {
					state[3] = exphone(state[3],1200,3,10)
				}
				if (state[3] == 1200) {
					state[0] = 'mainmenu'
				}
			}
		}
		else if (state[0].substr(0,8) == 'mainlose') {
			push()
			translate(state[2],state[3])
			rotate(state[4]/100)
			fill(250,250,240)
			rect(0,0,650,750)
			rect(0,-300,600,70)
			rect(0,-50,600,430)
			rect(0,100,600,200)
			fill(0)
			textSize(40)
			textFont('calibri')
			temp = parseInt(state[0].split('#')[1])
			if (state[2] == 0) {text(bombs[temp][0],0,-300)}//identifier
			else {text('Practice',0,-300)}
			textSize(30)
			if (state[2] == 0) {text(bombs[temp][5],0,-200)}
			else {text('cool',0,-200)}
			text(`Time Remaining: ${floor(level.time/60)}:${(floor(level.time)%60).toString().padStart(2,'0')}\nCause: ${level.expcause.toString()}`,0,100)
			text('Back',-250,230)
			push()
			stroke(200,0,0)
			noFill()
			rect(0,-70,300,100)
			rect(0,-70,280,80)
			fill(200,0,0)
			textSize(55)
			text('Exploded',0,-70)
			if (fade > 0) {
				fade -= 15
			}
			pop()
			pop()
			fill(0,fade)
		  rect(0,0,3000,2000)
			if (state[3] == 0) {
				if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,-250,230,100,100,0,0)) {
					cursor(HAND)
					if (mb == 2) {
						state[0] = 'mainwin-b#' + temp.toString()
					}
				}
			}
			if (state[0].substr(0,9) == 'mainwin-b') {
				state[3] = exphone(state[3],1200,10,10)
				if (keys.includes(32)) {
					state[3] = exphone(state[3],1200,3,10)
				}
				if (state[3] == 1200) {
					state[0] = 'mainmenu'
				}
			}
		}
		else if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,365,-275,30,150,0,0) || touching(mouseX-windowWidth/2,mouseY-windowHeight/2,0,0,700,800,0,0)) {
			cursor(HAND)
			if (mb == 2) {
				state[0] = 'main#menu'
			}
		}
		if (state[0].substr(0,4) == 'main' && state[0].substr(0,5) != 'main-') {
			if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,365,-155,30,150,0,0) && practice[0] == 0) {
				cursor(HAND)
				if (mb == 2) {
					practice[1] = 200
					state[0] = 'main#practice'
				}
			}
			else if (touching(mouseX-windowWidth/2,mouseY-windowHeight/2,565,-155,30,150,0,0) && practice[0] == 200) {
				cursor(HAND)
				if (mb == 2) {
					practice[1] = 0
					state[0] = 'main#practice'
				}
			}
		}
		if (state[0].substr(0,4) == 'main' && state[0].substr(0,5) != 'main-' && practice[0] == 200) {
			textSize(16)
			temp2 = ['breakers','thebutton','keypad','thebutton2','capacitors','fnf','twobits','whosfirst','oven','concheck','switches','keypadloops','password','topsyturvy']
			for (let i = 0; i < temp2.length; i++) {
				if (relativeMouseOn(200,120,240,(i-9)*50,textWidth(temp2[i])+20,25)) {
					cursor(HAND)
					if (mb == 2) {
						instanttrans = i
					}
				}
			}
		}
		if (instanttrans != -1) {
			fade += 15
			fill(0,fade)
			rect(0,0,3000,2000)
			if (fade > 1000) {
				setupGame(instanttrans,true)
				state = ['almost',100,instanttrans,1,0,0]
				instanttrans = -1
			}
		}
	}
	else if (state[0] == 'almost') {
		state[1] -= 1
		background(0)
		level.drawTimer(false)
		if (state[1] <= 0) {
			state = ['play',state[2],state[3],0,0,0]
			for (let self of level.modules) {
				self.setup()
			}
		}
	}
	else if (state[0] == 'win') {
		if (state[1] < 1) {
			fade += 15
			if (fade > 500) {
				state = ['mainwin#' + state[5].toString(),-1,state[2],0,random()*24-12,0]
				lookup = [0,0]
			}
		}
		else {
			fade = 0
			state[1] -= 1
		}
		textFont('arial')
		textAlign(LEFT,CENTER)
		turnx = 0
		turny = 0
		fill(170)
		rectMode(CENTER)
		rect(0,0,1050,700)
		temp = true
		if (floor(state[1]/30 % 2) == 0) {
			temp = false
		}
		level.drawTimer(true,temp)
		for (let self of level.modules) {
			self.drawThis()
			for (let self2 of self.inputs) {
				self2.drawThis()
			}
			self.final()
		}
		fill(0,fade)
		rect(0,0,3000,2000)
	}
	else if (state[0] == 'lose') {
		if (state[1] < 1) {
			state = ['mainlose#' + state[5].toString(),-1,state[2],0,random()*24-12,0]
			lookup = [0,0]
		}
		else {
			state[1] -= 1
		}
		textFont('arial')
		textAlign(LEFT,CENTER)
		turnx = 0
		turny = 0
		fill(170)
		rectMode(CENTER)
		fill(0)
		rect(0,0,3000,2000)
	}
	pop()
	pkeys = structuredClone(keys)
}