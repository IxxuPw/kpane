//-=-=-=--=-=--=-=-=-=-=-= GAME =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
class Game {
	constructor(x,y,fails,time,modules=[],size=1) {
		this.x = x
		this.y = y
		this.fails = fails
		this.time = time
		this.modules = modules
		this.amphours = 0
		this.serial = makeid(7)
		this.pports = 0
		this.mports = 0
		this.gports = 0
		this.strtime = ''
		this.batteries = 0
		this.expcause = []
		this.size = size
		
		if (this.size == 1) {
			this.rightdds = this.gendds(4)
			this.leftdds = concat([[['serial',''],0]],this.gendds(4,2))//dds = doodads
		}
		else {
			this.rightdds = this.gendds(6,-2)
			this.leftdds = concat(concat(this.gendds(0,-2),[[['serial',''],0]]),this.gendds(6,2))//dds = doodads
		}
		this.updds = this.gendds(6)//dds = doodads
		this.downdds = this.gendds(6)//dds = doodads
	}
	gendds(amt,offset=0) {
		temp = offset
		var a = []
		while (temp < amt) {
			if (temp == amt-1) {
				temp2 = random(size1dd)
			}
			else {
				temp2 = random(alldds)
			}
			a.push([temp2,temp*175])
			if (size1dds.includes(temp2[0])) {
				temp += 1
			}
			else {
				temp += 2
			}
			if (batteries.includes(temp2[0])) {
				this.amphours += bamphours[temp2[0]+temp2[1]]
				this.batteries += 1
			}
			if (compareValues(temp2,['aa batteries',''])) {
				this.batteries += 1
			}
			if (temp2[0] == 'parallel port') {
				this.pports += 1
			}
			if (temp2[0] == 'midi port') {
				this.mports += 1
			}
			if (temp2[0] == 'gamecube port') {
				this.gports += 1
			}
		}
		return a
	}
	drawTimer(a = true,b = true) {
		push()
		translate(this.x,this.y)
		if (a) {
			fill(90)
			rect(0,0,300,300)
			fill(120)
			rect(0,0,280,280)
			fill(100)
			rect(0,71,130,50,5,5,5,5)
			rect(0,-19,250,100,5,5,5,5)

			rect(0,70,130,50,5,5,5,5)
			rect(0,-20,250,100,5,5,5,5)
			fill(255,0,0)
			stroke(255)
			textSize(50)
			textAlign(CENTER,CENTER)
			switch (this.fails) {
				case 2: text('X',20,72);//no break lol
				case 1: text('X',-20,72);
			}
		}
		if (b) {
			noStroke()
			fill(0,255,0)
			if (this.time > 60 || state[2] == 1) {
				seg7(-42,-10,floor(this.time/600))//ll
				seg7(-16,-10,floor((this.time%600)/60))//l
				seg7(16,-10,floor((this.time%60)/10))//r
				seg7(42,-10,floor(this.time%10))//rr
				rect(0,-40,8,8)//top colon
				this.strtime = floor(this.time/60).toString().padStart(2,'0') + floor(this.time%60).toString().padStart(2,'0')
			}
			else {
				seg7(-42,-10,floor(this.time/10))//ll
				seg7(-16,-10,floor(this.time%10))//l
				seg7(16,-10,floor((this.time%1)*10))//r
				seg7(42,-10,floor((this.time%0.1)*100))//rr
				this.strtime = floor(this.time%60).toString().padStart(2,'0') + floor((this.time%1)*100).toString().padStart(2,'0')
			}
			rect(0,0,8,8)//bottom colon
			stroke(0)
		}
		pop()
	}
	tick() {
		temp = true
		for (var i of this.modules) {
			if (!i.complete) {
				temp = false
			}
		}
		if (temp == true) {
			state = ['win',300,state[2],0,0,state[1]]
		}
		if (this.fails > 2 || (this.time <= 0 && state[2] != 1)) {
			state = ['lose',300,state[2],0,0,state[1]]
			if (this.time <= 0) {
				this.expcause.push('Timer')
			}
		}
	}
	addFail(cause=null,remove=1) {
		this.fails += remove
		if (cause != null) {
			this.expcause.push(cause)
		}
		for (let i of this.modules) {
			if (i.amFnf) {
				i.genSeq()
			}
		}
	}
}

class Module {
	constructor(x,y,complete=false,error=0) {
		this.x = x
		this.y = y
		this.complete = complete
		this.error = error
		this.inputs = []
		this.recieve = []
		this.fineRecieve = []
	}
	drawThis(col1=190,col2=220) {
		push()
		translate(this.x,this.y)
		fill(col1)
		rect(0,0,300,300)
		fill(col2)
		rect(0,0,280,280)
		fill(col1)
		rect(130,-130,40,40,0,0,0,10)
		if (this.error > 0) {fill(255,0,0)}
		else if (this.complete) {fill(0,255,0)}
		else {fill(100)}
		circle(130,-130,20)
		pop()
	}
	tick() {
		this.recieve = []
		this.fineRecieve = []
		for (var ins of this.inputs) {
			ins.ifPressed()
			ins.drawThis()
		}
		if (this.error > 0) {
			this.error -= 1
		}
	}
	setup() {}
	final() {}
}

// -=-=-=-=-=-=--=-=-=-= MODULES =-=-=-=-=-=-=-=-=-=-=-=-

class TestM extends Module {
	constructor(x,y,complete,error,code) {
		super(x,y,complete,error)
		this.code = code
		new ModuleButton(this,'b1',0,0,80,50,20)
		new ModuleButton(this,'b2',0,50,30,30,10,1)
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		textSize(16)
		textAlign(CENTER,CENTER)
		fill(0)
		text('you should not see this',0,100)
		text('Attempted to generate: '+this.code,0,120)
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.includes('b1')) {
			this.complete = true
		}
		if (this.recieve.includes('b2')) {
			level.addFail('TestM')
			this.error = 30
		}
	}
}

class Keypad extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.onkeypad = []
		this.order = []
		this.saved = ''
		this.oon = 0
	}
	setup() {
		this.saved = random(['⎆þ⛗⎁ⅇ⬢ə♽℮⛜∳⎔⌱⛠ℙ⍎','⛖⍼⎘ҏ◈♲⎇₾⬣⌬₠⍊⬡℥⎂∱','▧⏧⸎‽⅏⎚⏍⛡⏣ℷ▨⎗⅌⎘⌘⎙','⬢❏⛻⤁✑⛙❧⟰⤐✇❑⨕⤘⨍⪓⤊'])
		if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
	  }
		else {
			this.saved = this.saved.split("").reverse().join("")//reverse string
		}
		temp = this.saved
		for (var i of [1,2,3,4]) {
			do {
				temp3 = floor(random()*temp.length)
				temp2 = temp[temp3]
			} while (this.onkeypad.includes(temp2))
			temp = temp.replace(temp[temp3],'')
			this.onkeypad.push(temp2)
		}
		new ModuleButton(this,0,-50,-50,80,80,10,0,false,[this.onkeypad[0],40],[255,255,220])
		new ModuleButton(this,1,50,-50,80,80,10,0,false,[this.onkeypad[1],40],[255,255,220])
		new ModuleButton(this,2,-50,50,80,80,10,0,false,[this.onkeypad[2],40],[255,255,220])
		new ModuleButton(this,3,50,50,80,80,10,0,false,[this.onkeypad[3],40],[255,255,220])
		temp = []
		for (i of [0,1,2,3]) {
			temp[this.saved.indexOf(this.onkeypad[i])] = i
		}
		for (i of temp) {
			if (i != undefined) {
				this.order.push(i)
			}
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(170)
		rect(0,0,220,220)
		fill(0)
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			if (this.recieve[0] == this.order[this.oon]) {
				this.oon += 1
				temp = this.inputs[this.recieve[0]]
				temp.inactive = true
				temp.rgb = [temp.rgb[0]-90,temp.rgb[1]-90,temp.rgb[2]-90]
				if (this.oon == 4) {
					this.complete = true
				}
			}
			else {
				level.addFail('Keypad')
				this.error = 30
			}
		}
	}
}

class Breakers extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.wires = []
		this.correct = null
		this.colors = [0,0,0,0,0,0]
		this.inverse = 0
	}
	setup() {
		temp2 = random([2,3,3,4,4,5,5,6,6])
		temp = []
		for (var i = 0; i < temp2; i++) {
			temp.push(i)
		}
		for (i = 0; i < temp2; i++) {
			temp3 = random(['red','orange','yellow','green','blue','purple'])
			this.colors[['red','orange','yellow','green','blue','purple'].indexOf(temp3)] += 1
			this.wires.push([i,temp.splice(floor(random()*temp.length), 1)[0],temp3])
			new ModuleButton(this,i,-90,-80+i*35,40,20,5,0,false,['░▒░',10],[140,140,140])
		}
		if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
	  }
		else {
			this.inverse = temp2-1
		}
		if (temp2 == 2) {//start chec!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!1
			if (level.mports % 3 == 0) {
				this.correct = abs(0 - this.inverse)//if midi ports multiple of 3
			}
			else if (this.wires[0][2] == this.wires[1][2]) {//otherwise if both same color
				this.correct = abs(1 - this.inverse)
			}
			else if (this.colors[5] == 1) {//otherwise if one purple
				if (this.wires[0][2] == 'purple') {
					this.correct = 0
				}
				else {
					this.correct = 1
				}
			}
			else if (this.wires[0][0] != this.wires[0][1]) {//otherwise if they cross
				this.correct = abs(0 - this.inverse)
			}
			else {
				this.correct = abs(1 - this.inverse)
			}
		}
		else if (temp2 == 3) {
			if (this.colors[0] == 1) {
				for (var check3 of this.wires) {
					if (check3[2] == 'red') {
						this.correct = check3[1]
					}
				}
			}
			else if (this.wires[abs(2-this.inverse)][2] == 'yellow' ^ this.wires[abs(1-this.inverse)][2] == 'blue') {
					if (this.wires[2-this.inverse][2] == 'yellow') {
						this.correct = abs(2-this.inverse)
					}
					else {
						this.correct = abs(1-this.inverse)
					}
			}
			else if (this.colors[3] == 0) {
				this.correct = abs(0-this.inverse)
			}
			else {
				this.correct = abs(2-this.inverse)
			}
		}
		else if (temp2 == 4) {
			if (level.mports % 3 == 0) {//if mports multiple of 3
				if (this.colors.some(a => a >= 2)) {//if at least 2 colors same
					this.correct = abs(2-this.inverse)
				}
				else {
					this.correct = abs(1-this.inverse)
				}
			}
			else if (this.colors[4] == 1) {//otherwise if exactly one blue
				for (var check4 of this.wires) {
					if (check4[2] == 'blue') {
						this.correct = check4[1]
						break
					}
				}
			}
			else if (this.colors[3] == 0) {
				this.correct = abs(3-this.inverse)
			}
			else {
				this.correct = abs(0-this.inverse)
			}
		}
		else if (temp2 == 5) {
			if (this.colors[2] > 1) {//If there is more than one yellow wire
				if (this.inverse == 0) {
					temp2 = this.wires
				}
				else {
					temp2 = this.wires.reverse()
				}
				for (var check5 of temp2) {
					if (check5[2] == 'yellow') {
						temp = check5[1]
					}
					this.correct = temp
				}
			}
			else if (level.pports % 2 == 1 && level.mports % 2 == 1) {//Otherwise, if there is an odd number of parallel ports and an odd number of midi ports
				this.correct = abs(1-this.inverse)
			}
			else if (this.colors[3] > this.colors[4] + this.colors[5]) {//Otherwise, if there are more green wires than blue and purple wires combined
				this.correct = abs(4-this.inverse)
			}
			else if (this.colors[4] > this.colors[3] + this.colors[5]) {//Otherwise, if there are more blue wires than green and purple wires combined
				if (this.inverse == 0) {
					temp2 = this.wires
				}
				else {
					temp2 = this.wires.reverse()
				}
				for (var chock5 of temp2) {
					if (chock5[2] == 'blue') {
						this.correct = chock5[0]
						break
					}
				}
			}
			else if (this.colors[1] == 1) {//Otherwise, if there is exactly one orange wire
				this.correct = abs(1-this.inverse)
			}
			else {
				this.correct = abs(3-this.inverse)
			}
		}
		else if (temp2 == 6) {//6 breakers:
			if (['0','1','2','3','4','5','6','7','8','9'].includes(level.serial[6])) {//if the serial number ends in a number:
				if (this.colors[1] == 0 && this.colors[2] == 0) {//if there are no orange or yellow
					this.correct = abs(0 - this.inverse)
				}
				else if (level.mports % 2 != 0) {//otherwise, if there are an odd number of mports
					this.correct = abs(3 - this.inverse)
				}
				else {//otherwise
					this.correct = abs(5 - this.inverse)
				}
			}
			else if (this.colors[0] == 1 ^ this.colors[5] == 1) {//otherwise if there is exactly one red wire XOR exactly one purple wire
				if (this.colors[0] == 1) {temp = 'red'}
				else {temp = 'purple'}
				for (var check of this.wires) {
					if (check[2] == temp) {
						this.correct = check[1]
						break
					}
				}
			}
			else {//otherwise if there is two of only one color wire
				temp = 0
				for (var chock of [0,1,2,3,4,5]) {
					if (this.colors[chock] == 2) {
						temp += 1
						temp3 = chock
					}
				}
				if (temp == 1) {//toggle the breaker corresponding to the position of the right side plug middle of the two right side plugs that the two wires connect to. If the middle is between two positions, toggle the one closer to the last position.
					temp = 0
					for (var chack of this.wires) {
						if (temp == 0) {
							if (chack[2] == ['red','orange','yellow','green','blue','purple'][temp3]) {
								temp = 1
								temp2 = chack[1]
							}
						}
						else {
							if (chack[2] == ['red','orange','yellow','green','blue','purple'][temp3]) {
								temp2 = (temp2+chack[1])/2
								break
							}
						}
					}
					if (this.inverse == 0) {
						this.correct = ceil(temp2)
					}
					else {
						this.correct = floor(temp2)
					}
				}
				else {
					this.correct = abs(0 - this.inverse)
				}
			}
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(160)
		rect(-90,15,80,230)
		fill(40)
		rect(45,15,170,230)
		fill(100)
		for (var wire of this.wires) {
			strokeWeight(10)
			stroke(wire[2])
			line(-35,-80+wire[0]*35,125,-80+wire[1]*35)
			strokeWeight(1)
			stroke(0)
			rect(-35,-80+wire[0]*35,10,25)
			rect(125,-80+wire[1]*35,10,25)
		}
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			temp = this.inputs[this.recieve[0]]
			temp.inactive = true
			temp.rgb = [temp.rgb[0]-40,temp.rgb[1]-40,temp.rgb[2]-40]
			if (this.recieve[0] == this.correct) {
				this.complete = true
			}
			else {
				level.addFail('Breakers')
				this.error = 30
			}
		}
	}
}

class Fnf extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.arrows = ['↑','⇑','⤊','⟰','↓','⇓','⤋','⟱','←','⇐','⇚','⭅','→','⇒','⇛','⭆']
		this.sequence = []
		this.display = []
		this.correct = []
		this.log = ''
		this.amFnf = true
		this.inversed = false
		this.table = [['2', '3'], ['0', '4'], ['2', '4'], ['2', '1'], ['3', '3'], ['2', '4'], ['3', '2'], ['1', '2'], ['2', '2'], ['3', '4'], ['2', '1'], ['2', '1'], ['1', '2'], ['0', '3'], ['3', '5'], ['0', '1'], ['2', '2'], ['3', '8'], ['1', '1'], ['1', '1'], ['3', '2'], ['0', '3'], ['3', '4'], ['3', '3'], ['3', '1'], ['0', '2'], ['1', '1'], ['2', '4'], ['3', '1'], ['1', '3'], ['3', '3'], ['1', '4'], ['1', '4'], ['2', '2'], ['2', '3'], ['1', '1'], ['0', '2'], ['0', '1'], ['0', '2'], ['0', '4'], ['2', '4'], ['0', '2'], ['1', '4'], ['1', '3'], ['0', '5'], ['1', '3'], ['3', '2'], ['0', '3']]
	}
	setup() {
		this.genSeq()
		new ModuleButton(this,2,-100,40,50,50,10,1,false,['🡰',30],[255,0,255])
		new ModuleButton(this,1,-35,40,50,50,10,1,false,['🡳',30],[100,130,255])
		new ModuleButton(this,0,35,40,50,50,10,1,false,['🡱',30],[0,255,0])
		new ModuleButton(this,3,100,40,50,50,10,1,false,['🡲',30],[255,0,0])
	}
	genSeq() {
		this.sequence = []
		this.display = []
		this.correct = []
		this.log = ''
		for (let i of [0,1,2,3,4,5,6]) {
			this.sequence.push(random(this.arrows))
		}
		this.display = structuredClone(this.sequence)
		if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
	  	this.inversed = false
		}
		else {
			this.sequence = this.sequence.reverse()
			this.inversed = true
		}
		if (level.fails != 3) {
			for (let i of this.sequence) {
				temp = this.arrows.indexOf(i)*3
				temp += level.fails
				for (let j = 0; j < this.table[temp][1]; j++) {
					this.correct.push(this.table[temp][0])
				}
			}
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(60)
		rect(0,-50,250,100)
		rect(0,105,250,40)
		fill(255)
		textSize(32)
		if (this.log.length <= 14) {
			text(this.log,-120,108)
		}
		else {
			text(this.log.slice(this.log.length-14),-120,108)
		}
		textSize(35)
		textAlign(CENTER,CENTER)
		temp = ''
		for (let i of this.display) {
			temp += i
		}
	  text(temp,0,-50)
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			if (this.inversed) {
				this.recieve[0] = [1,0,3,2][this.recieve[0]]
			}
			if (this.recieve[0] == this.correct[0]) {
				this.correct.shift()
				this.log += ['🡱','🡳','🡰','🡲'][this.recieve[0]]
				if (this.correct.length == 0) {
					this.complete = true
				}
			}
			else {
				level.addFail('Fnf')
				this.error = 30
				this.genSeq()
			}
		}
	}
}

class TheButton2 extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.letgoon = '-'
		this.log = []
		this.display = ''
		this.button = null
		this.pattern = []
		this.stage = 0
		this.table = {'SEE': 'HHLHPH', 'SEA': 'HLPHHH', 'C': 'HPHPHPH', 'CEE': 'HLLHHPH', 'RAISE': 'HHHLLH', 'RAYS': 'HPPPHHH', 'RASE': 'HHPLPHH', 'RAZE': 'HHHLH', 'CENTS': 'HPHLHPH', 'CENSE': 'HPPHLHH', 'SCENTS': 'HHPPHLH', 'SENSE': 'HPPPPLHHH', 'OR': 'HHHLPLPH', 'OAR': 'HPPHPPHLH', 'ORE': 'HPPHPHLH', 'UHHH': 'HPLHPLHH', 'WHAT': 'HHPPHH', 'YES': 'HHLLHH', 'NO': 'HPLHHLH', 'THERE': 'HLHPLPHH', 'THEIR': 'HHPLHPLH', "THEY'RE": 'HLPHHLPLH', 'BLANK': 'HPPPHHLH', 'NOTHING': 'HPLLLHHH', '⠀': 'HHPPHLLH', 'OKAY': 'HLHLLHLH', 'IT': 'HLHHLHPH', 'THAT': 'HHHLLPH', '4': 'HHLLLLHH', 'FOUR': 'HPHHLH', 'FOR': 'HPLHHLH', 'FORE': 'HLLLHPHH'}
		this.txt = random(['SEE','SEA','C','CEE','RAISE','RAYS','RASE','RAZE','CENTS','CENSE','SCENTS','SENSE','OR','OAR','ORE','UHHH','WHAT','YES','NO','THERE','THEIR',"THEY'RE",'BLANK','NOTHING','⠀','OKAY','IT','THAT','4','FOUR','FOR','FORE'])
		this.table2 = {'SEE': '0', 'SEA': '5', 'C': '3', 'CEE': '2', 'RAISE': '1', 'RAYS': '0', 'RASE': '9', 'RAZE': '8', 'CENTS': '7', 'CENSE': '9', 'SCENTS': '4', 'SENSE': '6', 'OR': '3', 'OAR': '5', 'ORE': '2', 'UHHH': '3', 'WHAT': '4', 'YES': '1', 'NO': '1', 'THERE': '6', 'THEIR': '7', "THEY'RE": '8', 'BLANK': '2', 'NOTHING': '0', '⠀': '3', 'OKAY': '3', 'IT': '4', 'THAT': '5', '4': '7', 'FOUR': '6', 'FOR': '9', 'FORE': '8'}
		this.table3 = [0,1,3,2,3,0,3,0,1,1,2,2]
	}
	setup() {
		this.button = new ModuleButton(this,1,-20,-20,200,200,25,1,true,[this.txt,40,255])
	  this.pattern = this.table[this.txt].split('')
		if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
		}
		else {
			this.pattern = this.pattern.reverse()
		}
	}
  randWhosOnFirst() {
		return random(['SEE','SEA','C','CEE','RAISE','RAYS','RASE','RAZE','CENTS','CENSE','SCENTS','SENSE','OR','OAR','ORE','UHHH','WHAT','YES','NO','THERE','THEIR',"THEY'RE",'BLANK','NOTHING','⠀','OKAY','IT','THAT','4','FOUR','FOR','FORE'])
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(60)
		rect(-20,110,200,30)
		rect(110,110,40,30)
		rect(110,70,40,30)
		//fill(255,0,255)
		//textAlign(LEFT,CENTER)
		//text(this.pattern,100,-80)
		//text(this.log,100,-50)
		//text(this.letgoon,100,-20)
		//text(level.strtime,100,10)
		//text(this.button.presstime,100,40)
		fill(255)
		textSize(30)
		textAlign(CENTER,CENTER)
		text(this.display,-20,110)
		pop()
	}
	tick() {
		super.tick()
		if (this.stage == 0) {
			if (this.fineRecieve.length != 0) {
				if (this.fineRecieve[0].length == 3) {
					if ((this.fineRecieve[0][2] <= 8 && this.pattern[0] == 'P') || (this.fineRecieve[0][2] > 8 && this.pattern[0] == 'L')) {
					}
					else if (this.fineRecieve[0][2] > 8 && this.pattern[0] == 'H') {
						this.log.push(this.display)
					}
					else {
						this.error = 30
						level.addFail('The Button 2')
					}
					this.pattern.shift()
					if (this.pattern.length == 0) {
						this.stage = 1
						this.display = ''
					}
				}
			}
			if (this.stage == 0) {
				if (this.button.yoff > 0 && this.button.presstime == 0) {
					this.display = this.randWhosOnFirst()
				}
				else if (this.button.presstime == 2) {
					this.display = this.randWhosOnFirst()
				}
				else if (this.button.presstime == 0) {
					this.display = ''
				}
			}
		}
		else {
			if (this.button.presstime == 9) {
				this.display = random(['1','2','3','4'])
				this.letgoon = this.table2[this.log[this.table3[(parseInt(this.display)-1)*3+level.fails]]]//get the number to let go on from random number 1-4 and fails
			}
			else if (this.fineRecieve.length != 0) {
				if (this.fineRecieve[0].length == 3) {
					if (level.strtime.includes(this.letgoon)) {
						this.complete = true
					}
					else {
						this.error = 30
						level.addFail('The Button 2')
					}
					this.letgoon = '-'
					this.display = ''
				}
			}
		}
	}
}

class TheButton extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.button = null
		this.correct = ''
		this.letgoon = '-'
    this.colors = random([[240,100,100],[240,100,100],[240,240,240],[100,100,240],[100,100,240],[240,240,100],[50,50,50]])
		this.lights = 60
		this.txt = random(['PRESS','ABORT','STOP','DET','HOLD','HOLD','COMEDY','ON','OFF'])
		this.prevval = 0
	}
	setup() {
		temp = 255
		if (compareValues(this.colors,[240,240,240]) || compareValues(this.colors,[240,240,100])) {
			temp = 0
		}
		this.button = new ModuleButton(this,1,-20,20,200,200,25,1,true,[this.txt,40,temp],this.colors)
		if (compareValues(this.colors,[100,100,240]) && this.txt == 'ABORT') {
			this.correct = 'hold'
		}
		else if (level.batteries > 7 && this.txt == 'DET') {
			this.correct = 'press'
		}
		else if (compareValues(this.colors,[240,240,240]) && level.mports > level.gports) {
			this.correct = 'hold'
		}
		else if (level.batteries > 10 && (level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0))) {
			this.correct = 'press'
		}
		else if (compareValues(this.colors,[240,240,100])) {
			this.correct = 'hold'
		}
		else if (compareValues(this.colors,[240,100,100]) && this.txt == 'HOLD') {
			this.correct = 'press'
		}
		else {
			this.correct = 'hold'
		}
	}
	drawThis() {
		super.drawThis()
		temp2 = this.button.touchingMe()
		if (temp2) {temp2 = exphone(this.prevval,1,10,0.001)}
		else {temp2 = exphone(this.prevval,0,10,0.001)}
		temp = max(this.button.yoff/this.button.h2*-4,temp2)
		this.prevval = temp
		push()
		translate(this.x,this.y)
		fill(this.lights)
		rect(110,20,30,200)
		fill(150,150,255,100)
		rect(-20,-110-(temp*20),220,40*(temp+1))
		pop()
	}
	final() {
		temp2 = this.button.touchingMe()
		if (temp2) {temp2 = this.prevval}
		else {temp2 = exphone(this.prevval,0,10,0.001)}
		temp = max(this.button.yoff/this.button.h2*-4,temp2)
		this.prevval = temp
		push()
		translate(this.x,this.y)
		fill(200,200,255,100)
		rect(-20,-20-(temp*40)+(-13*(temp*8)),220,220-26*(temp*8))
		fill(150,150,255,100)
		rect(-20,110-(temp*124)+(-13*(temp*8)),220,40*(temp+1))
		pop()
		
	}
	tick() {
		super.tick()
		if (this.button.presstime == 9) {
			this.lights = random(['red','white','white','blue','blue','yellow','yellow','green','purple'])
			if (this.lights == 'blue') {
				this.letgoon = '4'
			}
			else if (this.lights == 'white') {
				this.letgoon = '1'
			}
			else if (this.lights == 'yellow') {
				this.letgoon = '5'
			}
			else {
				this.letgoon = '2'
			}
		}
		else if (this.fineRecieve.length != 0) {
			if (this.fineRecieve[0].length == 3) {
				if (this.fineRecieve[0][2] >= 9) {
					if (level.strtime.includes(this.letgoon) && this.correct == 'hold') {
						this.complete = true
					}
					else {
						this.error = 30
						level.addFail('The Button')
					}
					this.letgoon = '-'
					this.lights = 60
				}
				else {
					if (this.correct == 'press') {
						this.complete = true
					}
					else {
							this.error = 30
							level.addFail('The Button')
					}
				}
			}
		}
	}
}

class Capacitors extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.wires = []
		this.power = []
		this.correct = []
		this.inverse = 0
		this.C = 0
		this.G = 0
	}
	setup() {
		if (level.amphours > 25) {
			this.C = 1
		}
		if (level.gports >= 2) {
			this.G = 2
		}
		this.table = [5,1,0,3,this.G,this.C,0,3,2,4,3,1,4,this.G,this.C,2,2,this.C,3,2,0,4,this.C,5,0,2,1,this.G,1,1,5,0]
		temp2 = random([5,6,6,6])
		temp = []
		for (var i = 0; i < temp2; i++) {
			temp.push(i)
			this.power.push(0)
		}
		for (i = 0; i < temp2; i++) {
			temp3 = random([['red','red'],['blue','blue'],['yellow','yellow'],['red','blue'],['red','yellow'],['blue','yellow'],['yellow','yellow'],['red','blue']])
			this.wires.push([i,temp.splice(floor(random()*temp.length), 1)[0],temp3,random([100,'gold']),random([40,'lightgoldenrodyellow'])])
			new ModuleButton(this,[i,-1],-115,-80+i*35,20,20,5,0,false,['-',20],[180,180,180])
			new ModuleButton(this,[i,1],-90,-80+i*35,20,20,5,0,false,['+',20],[180,180,180])
			let extratemp = 0;
			if (temp3.includes('red')) {extratemp += 1}
			if (temp3.includes('blue')) {extratemp += 2}
			if (this.wires[this.wires.length-1][3] == 'gold') {extratemp += 4}
			if (this.wires[this.wires.length-1][1] > this.wires[this.wires.length-1][0]) {extratemp += 8}
			if (this.wires[this.wires.length-1][4] == 'lightgoldenrodyellow') {extratemp += 16}
			this.correct.push(this.table[extratemp])
		}
		new ModuleButton(this,'dc',-55,125,25,25,3,1,false,['🗲',15],[250,250,0])
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(160)
		circle(-55,125,30)
		rect(-90,15,80,230)
		fill(40)
		rect(45,15,170,230)
		fill(100)
		for (var wire of this.wires) {
			temp = this.wires.indexOf(wire)
			strokeWeight(5.5)
			stroke(wire[2][0])
			line(-32.5,-77.5+wire[0]*35,122.5,-77.5+wire[1]*35)
			stroke(wire[2][1])
			line(-32.5,-82.5+wire[0]*35,122.5,-82.5+wire[1]*35)
			strokeWeight(1)
			stroke(0)
			fill(wire[3])
			rect(-35,-80+wire[0]*35,10,25)
			fill(100)
			rect(125,-80+wire[1]*35,10,25)
			fill(wire[4])
			circle(-65,-80+wire[0]*35,20)
			fill(40)
			rect(-102.5,-65+wire[0]*35,45,5)
			fill('lightgoldenrodyellow')
			rect(-125+(9*this.power[temp])/2,-65+wire[0]*35,9*this.power[temp],5)
		}
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			temp = this.recieve[0]
			if (temp != 'dc') {
				this.power[temp[0]] += temp[1]
				this.power[temp[0]] = max(min(this.power[temp[0]], 5), 0)
			}
			else {
				if (compareValues(this.correct, this.power)) {
					this.complete = true
				}
				else {
					this.error = 30
					level.addFail('Capacitors')
				}
				for (let i = 0; i < this.power.length; i++) {
					this.power[i] = 0
				}
			}
		}
	}
}

class TwoBits extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		
		this.search = ''
		this.working = ['input',0]
		this.table = []
		temp = ['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99']
		for (let i = 0; i < 100; i++) {
			temp2 = floor(random()*temp.length)
			this.table.push(temp.splice(temp2,1)[0])
		}
		this.table2 = ['kb', 'dk', 'gv', 'tk', 'pv', 'kp', 'bv', 'vt', 'pz', 'dt', 'ee', 'zk', 'ke', 'ck', 'zp', 'pp', 'tp', 'tg', 'pd', 'pt', 'tz', 'eb', 'ec', 'cc', 'cz', 'zv', 'cv', 'gc', 'bt', 'gt', 'bz', 'pk', 'kz', 'kg', 'vd', 'ce', 'vb', 'kd', 'gg', 'dg', 'pb', 'vv', 'ge', 'kv', 'dz', 'pe', 'db', 'cd', 'td', 'cb', 'gb', 'tv', 'kk', 'bg', 'bp', 'vp', 'ep', 'tt', 'ed', 'zg', 'de', 'dd', 'ev', 'te', 'zd', 'bb', 'pc', 'bd', 'kc', 'zb', 'eg', 'bc', 'tc', 'ze', 'zc', 'gp', 'et', 'vc', 'tb', 'vz', 'ez', 'ek', 'dv', 'cg', 've', 'dp', 'bk', 'pg', 'gk', 'gz', 'kt', 'ct', 'zz', 'vg', 'gd', 'cp', 'be', 'zt', 'vk', 'dc']
		
		new ModuleButton(this,'b',-100,-10,40,50,10,0,false,['B',40],[240,240,240])
		new ModuleButton(this,'c',-50,-10,40,50,10,0,false,['C',40],[240,240,240])
		new ModuleButton(this,'d',0,-10,40,50,10,0,false,['D',40],[240,240,240])
		new ModuleButton(this,'e',50,-10,40,50,10,0,false,['E',40],[240,240,240])
		new ModuleButton(this,'g',100,-10,40,50,10,0,false,['G',40],[240,240,240])
		new ModuleButton(this,'k',-100,60,40,50,10,0,false,['K',40],[240,240,240])
		new ModuleButton(this,'p',-50,60,40,50,10,0,false,['P',40],[240,240,240])
		new ModuleButton(this,'t',0,60,40,50,10,0,false,['T',40],[240,240,240])
		new ModuleButton(this,'v',50,60,40,50,10,0,false,['V',40],[240,240,240])
		new ModuleButton(this,'z',100,60,40,50,10,0,false,['Z',40],[240,240,240])
		new ModuleButton(this,'que',-65,115,100,30,10,0,false,['QUERY',20],[240,240,240])
		new ModuleButton(this,'sub',65,115,100,30,10,0,false,['SUBMIT',20],[240,240,240])
	}
	setup() {
		this.correct = 0
		for (let i of level.serial) {
			if ('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.includes(i)) {
				this.correct = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.indexOf(i)+1
				break
			}
		}
		for (let i of level.serial.split('').reverse().join()) {
			if ('0123456789'.includes(i)) {
				this.correct += parseInt(i)*level.batteries
				break
			}
		}
		if (this.y < 0) {
			this.correct += 1
		}
		if (this.x == -350) {
			this.correct += 2
		}
		else if (this.x == 350) {
			this.correct += 4
		}
		else {
			this.correct += 8
		}
		this.correct %= 100
		for (let i of [0,1,2,3]) {
			this.correct = parseInt(this.table[this.correct])
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(40)
		rect(-20,-95,200,50)
		fill(240)
		push()
		scale(0.8,1)
		textSize(40)
		textAlign(CENTER,CENTER)
		if (this.working[0] == 'input') {
			temp = this.search.toUpperCase().padEnd(2,'_')
			text(temp[0]+' '+temp[1],-20/0.8,-95)
		}
		else if (['querying','strike','submitting'].includes(this.working[0])) {
			text('WORKING...',-20/0.8,-95)
		}
		else if (this.working[0] == 'results') {
			text(`RESULT: ${this.search}`,-20/0.8,-95)
		}
		else if (this.working[0] == 'done') {
			text('UPLOADED',-20/0.8,-95)
		}
		pop()
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			temp = this.recieve[0]
			if (!['que','sub'].includes(temp)) {
				if (this.search.length == 2 || ['strike','querying','submitting','results'].includes(this.working[0])) {
					level.addFail('Two Bits')
					this.error = 30
				}
				else {
					this.search += temp
				}
			}
			else {
				if (this.search.length != 2) {
					this.working = ['strike',600]
				}
				else if (['strike','querying','submitting','results'].includes(this.working[0])) {
					level.addFail('Two Bits')
					this.error = 30
				}
				else if (temp == 'que') {
					this.working = ['querying',600]
				}
				else if (temp == 'sub' && this.table[this.table2.indexOf(this.search)] != this.correct) {
					this.working = ['strike',600]
				}
				else if (temp == 'sub' && this.table[this.table2.indexOf(this.search)] == this.correct) {
					this.working = ['submitting',600]
				}
			}
		}
		if (['strike','querying','submitting','results'].includes(this.working[0])) {
			this.working[1]--
			if (this.working[1] <= 0) {
				switch (this.working[0]) {
					case 'strike':
						this.working = ['input',0]
						this.search = ''
						level.addFail('Two Bits')
						this.error = 30
						break
					case 'querying':
						this.working = ['results',150]
						this.search = this.table[this.table2.indexOf(this.search)]
						break
					case 'submitting':
						this.complete = true
						this.working = ['done',0]
						break
					case 'results':
						this.working = ['input',0]
						this.search = ''
						break
				}
			}
		}
	}
}

class WhosFirst extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.correct = []
		this.display = ''
		this.state = [0,0]
		this.correct = 0
		this.table = ['YES','FIRST','DISPLAY','OKAY','SAYS','NOTHING','⠀','BLANK','NO','LED','LEAD','READ','RED','REED','LEED','HOLD ON','YOU','YOU ARE','YOUR','YOU\'RE','UR','THERE','THEY\'RE','THEIR','THEY ARE','SEE','C','CEE']
		this.table2 = [2,1,5,1,5,2,4,3,5,2,5,3,0,4,4,5,3,5,3,0,0,5,4,3,2,5,1,4]//CHANGED: RED, YOU'RE, CEE
		this.table3 = ['READY','FIRST','NO','BLANK','NOTHING','YES','WHAT','UHHH','LEFT','RIGHT','MIDDLE','OKAY','WAIT','PRESS','YOU','YOU ARE','YOUR','YOU\'RE','UR','U','UH HUH','UH UH','WHAT?','DONE','NEXT','HOLD','SURE','LIKE']
		this.b0 = null
		this.b1 = null
		this.b2 = null
		this.b3 = null
		this.b4 = null
		this.b5 = null
		this.buttons1 = ['YES', 'OKAY', 'WHAT', 'MIDDLE', 'LEFT', 'PRESS', 'RIGHT', 'BLANK', 'READY', 'NO', 'FIRST', 'UHHH', 'NOTHING', 'WAIT']
		this.buttons2 = ['SURE', 'YOU ARE', 'YOUR', 'YOU\'RE', 'NEXT', 'UH HUH', 'UR', 'HOLD', 'WHAT?', 'YOU', 'UH UH', 'LIKE', 'DONE', 'U']
	}
	genSeq() {
		this.display = random(this.table)
		if (['READY','FIRST','NO','BLANK','NOTHING','YES','WHAT','UHHH','LEFT','RIGHT','MIDDLE','OKAY','WAIT','PRESS'].includes(this.display))
			temp = structuredClone(this.buttons1)
		else {
			temp = structuredClone(this.buttons2)
		}
		for (let i of [this.b0,this.b1,this.b2,this.b3,this.b4,this.b5]) {
			i.setLabel(temp.splice(floor(random()*temp.length),1)[0])
		}
		for (let i of this.getList()[[this.b0,this.b1,this.b2,this.b3,this.b4,this.b5][this.table2[this.table.indexOf(this.display)]].txt[0]]) {//convert display --> correct getlist list
			let did = false
			for (let j of [this.b0,this.b1,this.b2,this.b3,this.b4,this.b5]) {
				if (j.txt[0] == i) {
					this.correct = j.name
					did = true
					break
				}
			}
			if (did) {
				break
			}
		}
	}
	getList() {
		return {
			"READY":	["YES", "OKAY", "WHAT", "MIDDLE", "LEFT", "PRESS", "RIGHT", "BLANK", "READY", "NO", "FIRST", "UHHH", "NOTHING", "WAIT"],
			"FIRST":	["LEFT", "OKAY", "YES", "MIDDLE", "NO", "RIGHT", "NOTHING", "UHHH", "WAIT", "READY", "BLANK", "WHAT", "PRESS", "FIRST"],
			"NO":	["BLANK", "UHHH", "WAIT", "FIRST", "WHAT", "READY", "RIGHT", "YES", "NOTHING", "LEFT", "PRESS", "OKAY", "NO", "MIDDLE"],
			"BLANK":	["WAIT", "RIGHT", "OKAY", "MIDDLE", "BLANK", "PRESS", "READY", "NOTHING", "NO", "WHAT", "LEFT", "UHHH", "YES", "FIRST"],
			"NOTHING":	["UHHH", "RIGHT", "OKAY", "MIDDLE", "YES", "BLANK", "NO", "PRESS", "LEFT", "WHAT", "WAIT", "FIRST", "NOTHING", "READY"],
			"YES":	["OKAY", "RIGHT", "UHHH", "MIDDLE", "FIRST", "WHAT", "PRESS", "READY", "NOTHING", "YES", "LEFT", "BLANK", "NO", "WAIT"],
			"WHAT":	["UHHH", "WHAT", "LEFT", "NOTHING", "READY", "BLANK", "MIDDLE", "NO", "OKAY", "FIRST", "WAIT", "YES", "PRESS", "RIGHT"],
			"UHHH":	["READY", "NOTHING", "LEFT", "WHAT", "OKAY", "YES", "RIGHT", "NO", "PRESS", "BLANK", "UHHH", "MIDDLE", "WAIT", "FIRST"],
			"LEFT":	["RIGHT", "LEFT", "FIRST", "NO", "MIDDLE", "YES", "BLANK", "WHAT", "UHHH", "WAIT", "PRESS", "READY", "OKAY", "NOTHING"],
			"RIGHT":	["YES", "NOTHING", "READY", "PRESS", "NO", "WAIT", "WHAT", "RIGHT", "MIDDLE", "LEFT", "UHHH", "BLANK", "OKAY", "FIRST"],
			"MIDDLE":	["BLANK", "READY", "OKAY", "WHAT", "NOTHING", "PRESS", "NO", "WAIT", "LEFT", "MIDDLE", "RIGHT", "FIRST", "UHHH", "YES"],
			"OKAY":	["MIDDLE", "NO", "FIRST", "YES", "UHHH", "NOTHING", "WAIT", "OKAY", "LEFT", "READY", "BLANK", "PRESS", "WHAT", "RIGHT"],
			"WAIT":	["UHHH", "NO", "BLANK", "OKAY", "YES", "LEFT", "FIRST", "PRESS", "WHAT", "WAIT", "NOTHING", "READY", "RIGHT", "MIDDLE"],
			"PRESS":	["RIGHT", "MIDDLE", "YES", "READY", "PRESS", "OKAY", "NOTHING", "UHHH", "BLANK", "LEFT", "FIRST", "WHAT", "NO", "WAIT"],
			"YOU":	["SURE", "YOU ARE", "YOUR", "YOU'RE", "NEXT", "UH HUH", "UR", "HOLD", "WHAT?", "YOU", "UH UH", "LIKE", "DONE", "U"],
			"YOU ARE":	["YOUR", "NEXT", "LIKE", "UH HUH", "WHAT?", "DONE", "UH UH", "HOLD", "YOU", "U", "YOU'RE", "SURE", "UR", "YOU ARE"],
			"YOUR":	["UH UH", "YOU ARE", "UH HUH", "YOUR", "NEXT", "UR", "SURE", "U", "YOU'RE", "YOU", "WHAT?", "HOLD", "LIKE", "DONE"],
			"YOU'RE":	["YOU", "YOU'RE", "UR", "NEXT", "UH UH", "YOU ARE", "U", "YOUR", "WHAT?", "UH HUH", "SURE", "DONE", "LIKE", "HOLD"],
			"UR":	["DONE", "U", "UR", "UH HUH", "WHAT?", "SURE", "YOUR", "HOLD", "YOU'RE", "LIKE", "NEXT", "UH UH", "YOU ARE", "YOU"],
			"U":	["UH HUH", "SURE", "NEXT", "WHAT?", "YOU'RE", "UR", "UH UH", "DONE", "U", "YOU", "LIKE", "HOLD", "YOU ARE", "YOUR"],
			"UH HUH":	["UH HUH", "YOUR", "YOU ARE", "YOU", "DONE", "HOLD", "UH UH", "NEXT", "SURE", "LIKE", "YOU'RE", "UR", "U", "WHAT?"],
			"UH UH":	["UR", "U", "YOU ARE", "YOU'RE", "NEXT", "UH UH", "DONE", "YOU", "UH HUH", "LIKE", "YOUR", "SURE", "HOLD", "WHAT?"],
			"WHAT?":	["YOU", "HOLD", "YOU'RE", "YOUR", "U", "DONE", "UH UH", "LIKE", "YOU ARE", "UH HUH", "UR", "NEXT", "WHAT?", "SURE"],
			"DONE":	["SURE", "UH HUH", "NEXT", "WHAT?", "YOUR", "UR", "YOU'RE", "HOLD", "LIKE", "YOU", "U", "YOU ARE", "UH UH", "DONE"],
			"NEXT":	["WHAT?", "UH HUH", "UH UH", "YOUR", "HOLD", "SURE", "NEXT", "LIKE", "DONE", "YOU ARE", "UR", "YOU'RE", "U", "YOU"],
			"HOLD":	["YOU ARE", "U", "DONE", "UH UH", "YOU", "UR", "SURE", "WHAT?", "YOU'RE", "NEXT", "HOLD", "UH HUH", "YOUR", "LIKE"],
			"SURE":	["YOU ARE", "DONE", "LIKE", "YOU'RE", "YOU", "HOLD", "UH HUH", "UR", "SURE", "U", "WHAT?", "NEXT", "YOUR", "UH UH"],
			"LIKE":	["YOU'RE", "NEXT", "U", "UR", "HOLD", "DONE", "UH UH", "WHAT?", "UH HUH", "YOU", "LIKE", "SURE", "YOU ARE", "YOUR"]
		}
	}
	setup() {
		this.b0 = new ModuleButton(this,0,-85,0,80,30,10,0,false,['',16],[255,255,220])
		this.b1 = new ModuleButton(this,1,15,0,80,30,10,0,false,['',16],[255,255,220])
		this.b2 = new ModuleButton(this,2,-85,50,80,30,10,0,false,['',16],[255,255,220])
		this.b3 = new ModuleButton(this,3,15,50,80,30,10,0,false,['',16],[255,255,220])
		this.b4 = new ModuleButton(this,4,-85,100,80,30,10,0,false,['',16],[255,255,220])
		this.b5 = new ModuleButton(this,5,15,100,80,30,10,0,false,['',16],[255,255,220])
		this.genSeq()
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(100)
		rect(-35,50,200,160)
		rect(-35,-90,200,70)
		rect(95,20,50,220)
		fill(60)
		rect(-35,50,190,140)
		rect(-35,-90,160,50)
		rect(-35,-90,190,60)
		fill(40)
		rect(-35,-90,160,50)
		rect(95,20,40,200)
		fill(240)
		textSize(25)
		textAlign(CENTER,CENTER)
		text(this.display,-35,-90)
		for (let i = 2; i >= 0; i--) {
			if (this.state[0] > i) {
				fill(0,240,0)
			}
			else {
				fill(60)
			}
			rect(95,90-(i*70),30,40)
		}
		pop()
	}
	tick() {
		super.tick()
		if (this.state[1] == 0) {
			if (this.recieve.length != 0) {
				if (this.recieve[0] == this.correct) {
					this.state[0] += 1
					this.state[1] = 60
					this.display = ''
					for (let i of [this.b0,this.b1,this.b2,this.b3,this.b4,this.b5]) {
						i.yoff = i.h2/5*4
						i.rgb = [i.rgb[0]-90,i.rgb[1]-90,i.rgb[2]-90]
						i.inactive = true
					}
					if (this.state[0] == 3) {
						this.complete = true
					}
				}
				else {
					this.error = 30
					level.addFail('W.O.F.')
				}
			}
		}
		else if (!this.complete) {
			this.state[1]--
			if (this.state[1] == 0) {
				for (let i of [this.b0,this.b1,this.b2,this.b3,this.b4,this.b5]) {
					i.inactive = false
					i.rgb = [i.rgb[0]+90,i.rgb[1]+90,i.rgb[2]+90]
				}
				this.genSeq()
			}
		}
	}
}

class Oven extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.open = 0.5
		this.state = ['open',0]
		this.timer = 0
		this.temperature = 400
		this.thing = [random(['s','c','r','e','p','t','h']),random(['red','orange','yellow','green','blue','purple',])]
		this.correct = null;
	}
	setup() {
		if (this.thing[1] == 'blue') {
			this.correct = 325
		}
		else if (['s','r'].includes(this.thing[0])) {
			this.correct = 475
		}
		else if (this.thing[0] == 'p') {
			this.correct = 600
		}
		else if (this.thing[1] == 'red') {
			this.correct = 275
		}
		else if (['c','e'].includes(this.thing[0])) {
			this.correct = 400
		}
		else if (this.thing[0] == 't') {
			this.correct = 380
		}
		else {
			this.correct = 525
		}
		if (['s','r','p','h'].includes(this.thing[0])) {
			this.correct += 15
		}
		if (level.amphours > 30) {
			this.correct += 5
		}
		if (['orange','yellow'].includes(this.thing[1])) {
			this.correct -= 25
		}
		if (['r','e'].includes(this.thing[0])) {
			this.correct -= 10
		}
		if (this.thing[1] == 'green') {
			this.correct += 5
		}
		if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
	  }
		else {
			this.correct = (725 - this.correct)+225
		}
		
		new ModuleButton(this,5,70,-110,30,20,8,0,true,['▲',20],[200,200,200])
		new ModuleButton(this,-5,70,-70,30,20,8,0,true,['▼',20],[200,200,200])
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
			
		push()
		translate(0,120)
		if (this.state[0] == 'baking') {
			temp = [224,137,29]
		}
		else {
			temp = [60,60,60]
		}
		fill(temp[0],temp[1],temp[2])
		rect(0,-80,230,160)
		fill(this.thing[1])
		switch (this.thing[0]) {
			case 's':
				rect(0,-80,60,60); break;
			case 'r':
				rect(0,-80,100,60); break;
			case 'c':
				circle(0,-80,60); break;
			case 'e':
				ellipse(0,-80,100,60); break;
			case 't':
				triangle(-30,-50,30,-50,0,-110); break;
			case 'p':
				beginShape()
				for (let i = 0; i < 6; i++) {
					vertex(cos(TAU/5*i-TAU/20)*40,sin(TAU/5*i-TAU/20)*40-82)
				}
				endShape(); break;
			case 'h':
				beginShape()
				for (let i = 0; i < 7; i++) {
					vertex(cos(TAU/6*i)*40,sin(TAU/6*i)*40-85)
				}
				endShape()
		}
		fill(100)
		rect(0,-47.5,220,5)
		scale(1,this.open)
		fill(200)
		beginShape();
		vertex(-115, -160);
		vertex(115, -160);
		vertex(115, 0);
		vertex(-115, 0);
		beginContour();
		vertex(-105, -130);
		vertex(-105, -10);
		vertex(105, -10);
		vertex(105, -130);
		endContour();
		endShape(CLOSE);
		fill(200,100)
		rect(0,-70,210,120)

		fill(100)
		rect(0,-145,80,15)
		pop()
		fill(160)
		rect(-35,-90,160,60)
		fill(40)
		rect(-35,-90,150,50)
		fill(255,0,0)
		noStroke()
		translate(20,-90)
		scale(0.6)
		seg7(0,0,'f')
		if (this.state[0] != 'done') {
			seg7(-90,0,floor(this.temperature/100))
			seg7(-60,0,floor(this.temperature/10)%10)
			seg7(-30,0,this.temperature%10)
		}
		else {
			seg7(-90,0,'-')
			seg7(-60,0,'-')
			seg7(-30,0,'-')
		}
		fill(255,0,255)
		//textSize(20)
		//text(this.state,200,-100)
		//text(this.correct,200,0)
		//text(state,200,100)
		pop()
	}
	tick() {
		super.tick()
		if (relativeMouseOn(this.x,this.y+120,0,-80*this.open,230,160*this.open)) {
			cursor(HAND)
			if (mb == 2) {
				if (this.state[0] == 'open') {
					this.state = ['baking',level.time]
				}
				else if (this.state[0] == 'baking') {
					if (this.state[1] > level.time+55.5 && this.state[1] < level.time+60.5 && this.temperature == this.correct && state[2] == 0) {
						this.complete = true
						this.state = ['done',0]
					}
					else if (this.state[1] < level.time-55.5 && this.state[1] > level.time-60.5 && this.temperature == this.correct && state[2] == 1) {
						this.complete = true
						this.state = ['done',0]
					}
					else {
						this.error = 30
						level.addFail('The Oven')
					}
					this.state = ['open',0]
				}
			}
		}
		if (this.recieve.length != 0) {
			temp = this.recieve[0]
			temp2 = this.fineRecieve[0]
			if (this.state[0] == 'open') {
				if (temp2[1] == 1) {
					this.temperature += temp
					this.temperature = min(max(225,this.temperature),725)
				}
				else if (temp2[1] > 15 && temp2[1] % 5 == 0) {
					this.temperature += temp
					this.temperature = min(max(225,this.temperature),725)
				}
			}
			else if (this.state[0] == 'baking') {
				if (temp2[1] == 1) {
					this.error = 30
					level.addFail('The Oven')
					//level.time+=16
				}
			}
		}
		if (this.state[0] == 'baking') {
			this.open = exphone(this.open,1,10,0.001)
		}
		else {
			this.open = exphone(this.open,0.5,10,0.001)
		}
	}
}

class ConCheck extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.onoff = [random([true,false]),random([true,false]),random([true,false]),random([true,false])]
		this.numbers = [floor(random()*8)+1,floor(random()*8)+1,floor(random()*8)+1,floor(random()*8)+1,floor(random()*8)+1,floor(random()*8)+1,floor(random()*8)+1,floor(random()*8)+1]
		this.b0 = null
		this.b1 = null
		this.b2 = null
		this.b3 = null
		this.correct = []
	}
	setup() {
		new ModuleButton(this,'check',-20,-80,170,40,10,0,false,['CHECK',30],[255,255,220])
		let a = {
			false: [240,30,30],
			true: [30,240,30]
		}
		this.b0 = new ModuleButton(this,0,-70,0,40,60,10,0,false,null,concat(a[this.onoff[0]],[255,255,220]))
		this.b1 = new ModuleButton(this,1,70,0,40,60,10,0,false,null,concat(a[this.onoff[1]],[255,255,220]))
		this.b2 = new ModuleButton(this,2,-70,80,40,60,10,0,false,null,concat(a[this.onoff[2]],[255,255,220]))
		this.b3 = new ModuleButton(this,3,70,80,40,60,10,0,false,null,concat(a[this.onoff[3]],[255,255,220]))
		
		temp = true
		for (let i = 0; i < this.numbers.length; i++) {
			for (let j = 0; j < this.numbers.length; j++) {
				if (i == j) {
					continue
				}
				if (this.numbers[i] == this.numbers[j]) {
					temp = false
				}
			}
		}
		if (temp) {
			temp2 = level.serial[6]
		}
		else if (this.numbers.filter(x => x==1).length >= 2) {
			temp2 = level.serial[0]
		}
		else if (this.numbers.filter(x => x==7).length >= 2) {
			temp2 = level.serial[5]
		}
		else if (this.numbers.filter(x => x==2).length >= 3) {
			temp2 = level.serial[1]
		}
		else if (!this.numbers.includes(5)) {
			temp2 = level.serial[4]
		}
		else if (this.numbers.filter(x => x==8).length == 2) {
			temp2 = level.serial[2]
		}
		else {
			temp2 = level.serial[(level.batteries-1)%7]
		}
		if ('SLIM'.includes(temp2)) {
			temp3 = [null,[3,6,2],[1,6],[1,6,4],[3,5,6,7,8],[4,6,7],[1,2,3,4,5],[4,5,8],[4,7]]
		}
		else if ('15BRO'.includes(temp2)) {
			temp3 = [null,[2,7],[1,7],[4,8],[3,8],[6,7],[5,7],[1,2,5,6],[3,4]]
		}
		else if ('20DGT'.includes(temp2)) {
			temp3 = [null,[2,3],[1,4,7],[1,5,7],[2,6,7,8],[3,6,7],[4,5,8],[3,4],[4,6]]
		}
		else if ('34XYZ'.includes(temp2)) {
			temp3 = [null,[2,4,6],[1,3,4],[2],[1,2,7],[6],[1,5,8],[4,6,8],[6,7]]
		}
		else if ('7HPJ'.includes(temp2)) {
			temp3 = [null,[2,3],[1,3],[1,2],[6,7],[6,7],[4,5],[4,5],[]]
		}
		else if ('6WUF'.includes(temp2)) {
			temp3 = [null,[2,3,4,5],[1,5,6],[1,4,6,7],[1,3,5,8],[1,2,4,6,7,8],[2,3,5,7],[3,5,6,8],[4,5,7]]
		}
		else if ('8CAKE'.includes(temp2)) {
			temp3 = [null,[2,3,6,8],[1,4,6],[1,4,6,7,8],[2,3,5,6,7],[4,7,8],[1,2,3,4],[3,4,5,8],[1,3,5,7]]
		}
		else if ('9QVN'.includes(temp2)) {
			temp3 = [null,[2,4,8],[1,3,6,7],[2,4,6,7],[1,3,5],[4,6,8],[2,3,5,7],[2,3,6,8],[1,5,7]]
		}
		this.correct.push(temp3[this.numbers[0]].includes(this.numbers[1]))
	  this.correct.push(temp3[this.numbers[4]].includes(this.numbers[5]))
	  this.correct.push(temp3[this.numbers[2]].includes(this.numbers[3]))
		this.correct.push(temp3[this.numbers[6]].includes(this.numbers[7]))
	}
	updateButtonColors() {
		let a = {
			false: [240,30,30],
			true: [30,240,30]
		}
		this.b0.rgb = concat(a[this.onoff[0]],[255,255,220])
		this.b1.rgb = concat(a[this.onoff[1]],[255,255,220])
		this.b2.rgb = concat(a[this.onoff[2]],[255,255,220])
		this.b3.rgb = concat(a[this.onoff[3]],[255,255,220])
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(235,235,190)
		rect(-70,0,120,60)
		rect(70,0,120,60)
		rect(-70,80,120,60)
		rect(70,80,120,60)
		fill(255,255,220)
		rect(-70,-5,120,60)
		rect(70,-5,120,60)
		rect(-70,75,120,60)
		rect(70,75,120,60)
		fill(0)
		textSize(30)
		textAlign(CENTER,CENTER)
		text(this.numbers[0],-110,-5)
		text(this.numbers[1],-30,-5)
		text(this.numbers[2],-110,75)
		text(this.numbers[3],-30,75)
		text(this.numbers[4],30,-5)
		text(this.numbers[5],110,-5)
		text(this.numbers[6],30,75)
		text(this.numbers[7],110,75)
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			temp = this.recieve[0]
			if ([0,1,2,3].includes(temp)) {
				this.onoff[temp] = !this.onoff[temp]
				this.updateButtonColors()
			}
			else if (temp == 'check') {
				if (compareValues(this.correct,this.onoff)) {
					this.complete = true
				}
				else {
					this.error = 30
					level.addFail('Conn. Check')
				}
			}
		}
	}
}

class Switches extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.switchState = [random([0,1]),random([0,1]),random([0,1]),random([0,1]),random([0,1])]
		this.sAnim = null
		this.correct = structuredClone(this.switchState)
		this.table = [
			'1,1,0,1,1',
			'1,0,1,0,0',
			'1,0,0,0,0',
			'0,1,1,0,1',
			'0,1,1,0,0',
			'0,1,0,0,0',
			'0,0,1,1,1',
			'0,0,1,0,1',
			'0,0,0,1,1',
			'0,0,0,0,1',
		]
	}
	setup() {
		/*if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
		}
		else {
			for (let i = 0; i < this.table.length; i++) {
				for (let j = 0; j < 5; j++) {
					this.table[i] = this.table[i].substring(0,j*2) + (parseInt(this.table[i][j*2]) ^ 1).toString() + this.table[i].substring(j*2 + 1)
				}
			}
		}*/
		while (this.table.includes(this.switchState.toString())) {
			this.switchState = [random([0,1]),random([0,1]),random([0,1]),random([0,1]),random([0,1])]
		}
		this.sAnim = structuredClone(this.switchState)
		temp = random([2,3,3,3,4,5])
		temp2 = [0,1,2,3,4]
		for (let i = 0; i < temp; i++) {
			this.correct[temp2.splice(floor(random()*temp2.length),1)] ^= 1
		}
		while (this.table.includes(this.correct.toString())) {
			this.correct = structuredClone(this.switchState)
			temp = random([2,3,3,3,4,5])
			temp2 = [0,1,2,3,4]
			for (let i = 0; i < temp; i++) {
				this.correct[temp2.splice(floor(random()*temp2.length),1)] ^= 1
			}
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		for (let i = 0; i < 5; i++) {
			fill(130)
			circle(50*(i-2),0,20)
			fill(60)
			quad(50*(i-2)+6,0,50*(i-2)-6,0,50*(i-2)-16,(this.sAnim[i]-0.5)*130,50*(i-2)+16,(this.sAnim[i]-0.5)*130)
		}
		for (let i = 0; i < 5; i++) {
			if (this.correct[i] == 1) {
				fill(0,255,0)
			} else {fill(40)}
			circle(50*(i-2),80,10)
			if (this.correct[i] == 0) {
				fill(0,255,0)
			} else {fill(40)}
			circle(50*(i-2),-80,10)
		}
		pop()
	}
	tick() {
		super.tick()
		for (let i = 0; i < 5; i++) {
			if (relativeMouseOn(this.x,this.y,50*(i-2),(this.sAnim[i]-0.5)*65,32,abs((this.sAnim[i]-0.5)*130))) {
				cursor(HAND)
				if (mb == 2) {
					this.switchState[i] ^= 1
					if (this.table.includes(this.switchState.toString())) {
						this.sAnim[i] = exphone(this.sAnim[i],this.switchState[i],3,0.00001)
						this.switchState[i] ^= 1
						this.error = 30
						level.addFail('Switches')
					}
					if (compareValues(this.correct,this.switchState)) {
						this.complete = true
					}
				}
			}
		}
		for (let i = 0; i < 5; i++) {
			this.sAnim[i] = exphone(this.sAnim[i],this.switchState[i],3,0.00001)
		}
	}
}

class KeypadLoops extends Module {
	constructor(x,y,complete=false,error=0) {
		super(x,y,complete,error)
		this.onkeypad = []
		this.order = []
		this.saved = ''
		this.oon = 0
		this.lines = []
	}
	setup() {
		this.saved = ['⬟⎗⛖℘∳▨⤖✀⎔⨏⛠❐⎚௹⨓⌱','⌬₻⤘⫱✁⬠⛜⬢⍼❑⨕⦹⤐⏣⭓✂','⛗❒⨖₾⭔⍎⤗⨔✃∮⸎႟⛡⊷⨐⬣','✑⛙∱⤅⅌❏▧₰⤁⯂⏧⎘⨍⍕✄⊶']
		if ((level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0)) && (level.pports >= 1)) {
	  	this.saved = this.saved.join("")
		}
		else if (["0","1","2","3","4","5","6","7","8","9"].includes(level.serial[6])) {
			this.saved = this.saved[0].split("").reverse().join("") + this.saved[1].split("").reverse().join("") + this.saved[2].split("").reverse().join("") + this.saved[3].split("").reverse().join("")
		}
		else if (level.batteries > 7) {
			temp = ''
			for (let i = 0; i < this.saved[0].length; i++) {
				for (let j = 0; j < this.saved.length; j++) {
					temp += this.saved[j][i]
				}
			}
			this.saved = temp
		}
		else {
			this.saved = this.saved.join("").split("").reverse().join("")//reverse string
		}
		this.copy = structuredClone(this.saved)
		for (var i of [0,1,2,3,4]) {
			do {
				temp3 = floor(random()*this.saved.length)
				temp2 = this.saved[temp3]
			} while (this.onkeypad.includes(temp2))
			this.saved = this.saved.replace(this.saved[temp3],'')
			this.onkeypad.push(temp2)
		}
		for (i of [4,3,0,2,1]) {
			new ModuleButton(this,[2,4,3,1,0][i],cos(i*TAU/5-PI/10)*70,sin(i*TAU/5-PI/10)*70,80,80,10,1,false,[this.onkeypad[[2,4,3,1,0][i]],40],[255,255,220])
		}
		this.findOrder()
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(170)
		circle(0,0,260)
		strokeWeight(5)
		for (let i of this.lines) {
			stroke(200,200,255,i[4]*10.2)
			line(i[0],i[1],i[2],i[3])
			i[4]--
			i[5].rgb = [255-i[4],255-i[4],220+i[4]]
			i[6].rgb = [255-i[4],255-i[4],220+i[4]]
			if (i[4] == 0) {
				this.lines.splice(this.lines.indexOf(i),1)
				i[5].rgb = [255,255,220]
				i[6].rgb = [255,255,220]
			}
		}
		pop()
	}
	findOrder() {
		temp = []
		this.order = []
		for (let i of [0,1,2,3,4]) {
			temp[this.copy.indexOf(this.onkeypad[i])] = i
		}
		for (let i of temp) {
			if (i != undefined) {
				this.order.push(i)
			}
		}
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			if (this.recieve[0] == this.order[0]) {
				this.oon += 1
				temp = this.inputs[this.recieve[0]]
				if (this.oon > 3) {
					temp.inactive = true
					temp.rgb = [temp.rgb[0]-90,temp.rgb[1]-90,temp.rgb[2]-90]
					this.order.shift()
				}
				else {
					temp3 = floor(random()*this.saved.length)
					temp2 = this.saved[temp3]
					while (this.onkeypad.includes(temp2)) {
						temp3 = floor(random()*this.saved.length)
						temp2 = this.saved[temp3]
					}
					this.saved = this.saved.replace(this.saved[temp3],'')
					this.onkeypad[temp.name] = temp2
					temp.setLabel(temp2)
					temp3 = floor(random()*this.saved.length)
					temp2 = this.saved[temp3]
					while (this.onkeypad.includes(temp2)) {
						temp3 = floor(random()*this.saved.length)
						temp2 = this.saved[temp3]
					}//dowhile loops do not work :(
					this.saved = this.saved.replace(this.saved[temp3],'')
					temp3 = floor(random()*4)
					if (temp3 >= temp.name) (temp3++)
					this.onkeypad[temp3] = temp2
					this.inputs[temp3].setLabel(temp2)
					this.lines.push([this.inputs[temp3].x,this.inputs[temp3].y,temp.x,temp.y,25,this.inputs[temp3],temp])
					this.findOrder()
				}
				if (this.oon == 8) {
					this.complete = true
					for (let i = 0; i < this.inputs.length; i++) {
						this.inputs[i].inactive = true
					}
				}
			}
			else {
				level.addFail('Keypad Loops')
				this.error = 30
			}
		}
	}
}

class Password extends Module {
	constructor(x,y,complete,error) {
		super(x,y,complete,error)
		this.cipher = []
		this.on = []
		this.word = ''
		this.submit = null
	}
	setup() {
		this.on = [floor(random()*5),floor(random()*5),floor(random()*5),floor(random()*5),floor(random()*5),floor(random()*5)]
		for (let i = 0; i < 6; i++) {
			new ModuleButton(this,i.toString()+'+',42*(i-2.5),-65,30,30,10,1,false,['▲',20],[200,200,200])
		  new ModuleButton(this,i.toString()+'-',42*(i-2.5),65,30,30,10,1,false,['▼',20],[200,200,200])
		}
		this.submit = new ModuleButton(this,'submit',0,115,200,35,10,0,false,['TSARATE VIDUTSIVAN',16],[200,200,200])
		this.table = ['ximoi', 'ediesa', 'dirkon', 'siada', 'vidian', 'entsa', 'tsune', 'akano', 'selica', 'tzera', 'vidan', 'aliva', 'manora', 'latsui', 'yatse', 'akana', 'ralei', 'tziren', 'rutene', 'renda', 'tunia', 'viaka', 'natsui', 'reauw', 'tzeiki', 'atzata', 'xigai', 'trota', 'padon', 'tokoni', 'sentsa', 'lodon', 'xiyila', 'noava', 'valvae', 'xakano', 'fineau', 'folea', 'penika', 'xisivi']
		this.table2 = ['ximoi ', ' ximoi', 'ediesa', 'dirkon', 'siada ', ' siada', 'vidian', 'entsa ', ' entsa', 'tsune ', ' tsune', 'akano ', ' akano', 'selica', 'tzera ', ' tzera', 'vidan ', ' vidan', 'aliva ', ' aliva', 'manora', 'latsui', 'yatse ', ' yatse', 'akana ', ' akana', 'ralei ', ' ralei', 'tziren', 'rutene', 'renda ', ' renda', 'tunia ', ' tunia', 'viaka ', ' viaka', 'natsui', 'reauw ', ' reauw', 'tzeiki', 'atzata', 'xigai ', ' xigai', 'trota ', ' trota', 'padon ', ' padon', 'tokoni', 'sentsa', 'lodon ', ' lodon', 'xiyila', 'noava ', ' noava', 'valvae', 'xakano', 'fineau', 'folea ', ' folea', 'penika', 'xisivi']
		this.alphabet = ['a', 'c', 'd', 'e', 'f', 'g', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
		this.word = random(this.table)
		if (this.word.length == 5) {
			if (random() > 0.5) {
				this.word = ' ' + this.word
			}
			else {
				this.word = this.word + ' '
			}
		}
		this.cipher = []
		for (let i = 0; i < 6; i++) {
			this.cipher.push([this.word[i]])
		}
		for (let j = 0; j < 6; j++) {
			temp2 = structuredClone(this.alphabet)
			if (this.cipher[j][0] != ' ') {
				temp2.splice(temp2.indexOf(this.cipher[j][0]),1)
			}
			for (let i = 0; i < 5; i++) {
				if (!(this.cipher[j].includes(' ')) && random() < 0.1 && j == 0) {
					this.cipher[j].push(' ')
				}
				else {
					temp3 = random(temp2)
					temp2.splice(temp2.indexOf(temp3),1)
					this.cipher[j].push(temp3)
				}
			}
		}
		let exttemp = true
		while (exttemp) {
			exttemp = false
			for (let i of this.table2) {
				if (i == this.word) {
					continue
				}
				for (let j = 0; j < 6; j++) {
					if (this.cipher[j].includes(i[j])) {
						if (j == 5) {
							exttemp = true
						}
					}
					else {
						break
					}
				}
				if (exttemp) {
					for (let j of [5,4,3,2,1,0]) {
						if (i[j] != this.word[j]) {
							this.cipher[j] = [this.cipher[j][0]]
							temp2 = structuredClone(this.alphabet)
							if (this.cipher[j][0] != ' ') {
								temp2.splice(temp2.indexOf(this.cipher[j][0]),1)
							}
							for (let i = 0; i < 5; i++) {
								if (!(this.cipher[j].includes(' ')) && random() < 0.1 && j == 0) {
									this.cipher[j].push(' ')
								}
								else {
									temp3 = random(temp2)
									temp2.splice(temp2.indexOf(temp3),1)
									this.cipher[j].push(temp3)
								}
							}
						}
					}
					break
				}
			}
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		textSize(30)
		textAlign(CENTER,CENTER)
		fill(100)
		rect(0,0,260,90)
		for (let i = 0; i < 6; i++) {
			fill(0,255,0)
			rect(42*(i-2.5),0,33,60)
			fill(30)
			text(this.cipher[i][this.on[i]].toUpperCase(),42*(i-2.5),0)
		}
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.length != 0) {
			temp = this.recieve[0]
			if (temp != 'submit') {
				if (temp[1] == '+') {
					this.on[parseInt(temp[0])] += 1
				}
				else {
					this.on[parseInt(temp[0])] += 5
				}
				this.on[parseInt(temp[0])] %= 6
			}
			else {
				if (compareValues([0,0,0,0,0,0],this.on)) {
					this.complete = true
					for (let i = 0; i < this.inputs.length; i++) {
						this.inputs[i].inactive = true
						this.inputs[i].rgb = [160,160,160]
						this.inputs[i].yoff = 6
					}
				}
				else {
					this.error = 30
					level.addFail('Password')
				}
			}
		}
	}
}

class TopsyTurvy extends Module {
	constructor(x,y,complete,error) {
		super(x,y,complete,error)
		
		this.table = ['⮠ ','⮡','⮢','⮣','⮤','⮥','⮦','⮧']
		this.table2 = [0.35,0,0.35,0,0.35,0,0,-0.03,0,0,-0.02]
		this.labels = []
		this.on = floor(this.table.length*random())
		this.mid = new ModuleButton(this,'mid',0,-10,80,80,10,1,true,[this.table[this.on],70],[200,200,200])
		this.defaultturn = random([0,1,2,3])
		this.turn = 0
		this.target = 0
		this.state = 'idle'
		this.timer = 60
		this.correct = [['p',3],['p',1],['h',0],['r',2]]
		this.points = 0
		this.isUp = 0
		this.saved = []
		this.possi = []
		this.centerarrow = this.table[this.on]
		
	}
	setup() {
		temp = ['⮜','⮞','⮝','⮟']
		for (let i = 0; i < 4; i++) {
			this.labels.push(temp.splice(floor(random()*temp.length),1)[0])
		}
		this.u = new ModuleButton(this,0,0,-110,40,40,8,1,true,[this.labels[0],30],[200,200,200])
		this.r = new ModuleButton(this,1,110,0,40,40,8,1,true,[this.labels[1],30],[200,200,200])
		this.d = new ModuleButton(this,2,0,110,40,40,8,1,true,[this.labels[2],30],[200,200,200])
		this.l = new ModuleButton(this,3,-110,0,40,40,8,1,true,[this.labels[3],30],[200,200,200])
		
		this.vowelin = (level.serial.includes('A') || level.serial.includes('E') || level.serial.includes('I') || level.serial.includes('O') || level.serial.includes('U') || (level.serial.includes('Y') && this.y < 0))
		this.updatePointing()
		
		if (this.vowelin && level.pports >= 1) {
			this.saved = [0.7,0.6,0.5,0.4,0.3,0.2,0.1,0]
		}
		else {
			this.saved = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7]
		}
		this.possi = structuredClone(this.saved)
		this.calcCorrect()
	}
	updatePointing() {
		if (['⮤','⮥'].includes(this.centerarrow)) {
			this.points = (100-this.defaultturn-this.target) % 4
		}
		if (['⮡','⮣'].includes(this.centerarrow)) {
			this.points = (101-this.defaultturn-this.target) % 4
		}
		if (['⮦','⮧'].includes(this.centerarrow)) {
			this.points = (102-this.defaultturn-this.target) % 4
		}
		if (['⮠ ','⮢'].includes(this.centerarrow)) {
			this.points = (103-this.defaultturn-this.target) % 4
		}
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		fill(120)
		circle(0,0,160)
		fill(150)
		circle(0,-10,160)
		push()
		translate(0,-10)
		rotate(PI*(this.defaultturn+this.turn)/2)
		stroke(200)
		for (let i = 0; i < 36; i++) {
			line(cos(PI/18*i)*45,sin(PI/18*i)*45,cos(PI/18*i)*75,sin(PI/18*i)*75)
		}
		textSize(25)
		textAlign(CENTER,CENTER)
		fill(0)
		stroke(0)
		text('UP',0,-55)
		//text(this.isUp,0,-85)
		pop()
		//fill(0)
		//text(this.correct,0,135)
		pop()
	}
	yeowch() {
		level.addFail('Topsy Turvy')
		this.error = 30
		this.state = 'idle'
		this.target = 0
		this.timer = 60
		this.updatePointing()
		this.calcCorrect()
	}
	calcCorrect() {
		this.possi = structuredClone(this.saved)
		if (this.vowelin) {
			this.possi[0]++
		}
		else {
			this.possi[1]++
		}
		if ('0123456789'.includes(level.serial[6])) {
			this.possi[1]++
			this.possi[6]++
		}
		if (level.serial.includes('W')) {
			this.possi[6]++
		}
		if (level.gports > 1) {
			this.possi[4]++
		}
		if (level.gports >= 3) {
			this.possi[7]++
		}
		if (level.gports % 2 == 1) {
			this.possi[6]++
		}
		if (level.mports > level.gports) {
			this.possi[0]++
		}
		if (level.mports >= 3) {
			this.possi[2]++
			if (level.mports > 3) {
				this.possi[0]++
				if (level.mports > 5) {
					this.possi[2]++
				}
			}
		}
		else if (level.mports < 3) {
			this.possi[7]++
		}
		if ([1,2,5].includes(level.mports)) {
			this.possi[6]++
		}
		if ([1,2,3,8,9].includes(level.batteries)) {
			this.possi[0]++
		}
		if (level.batteries % 2 == 0) {
			this.possi[1]++
		}
		if ([4,5,6].includes(level.batteries)) {
			this.possi[2]++
		}
		if (level.batteries < 7) {
			this.possi[3]++
		}
		if (level.pports % 2 == 0) {
			this.possi[1]++
		}
		if (level.pports == 0) {
			this.possi[3]++
		}
		else {
			this.possi[4]++
		}
		if (['⮡','⮢','⮥','⮦'].includes(this.centerarrow)) {//left
			this.possi[2]++
			this.possi[7]++
		}
		if (['⮠ ','⮣','⮤','⮧'].includes(this.centerarrow)) {//right
			this.possi[3]++
			this.possi[5]++
		}
		if (this.points == 0) {
			this.possi[3]++
		}
		if (this.points == 1) {
			this.possi[5]++
		}
		if (this.points == 3) {
			this.possi[4]++
		}
		if (this.points != 3) {
			this.possi[5]++
		}
		if (this.points == 1 || this.points == 3) {
			this.possi[7]++
		}
		temp = this.possi.indexOf(max(this.possi))
		//possibilities vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
		this.correct = []
		switch (temp) {
			case 0:
				this.correct = [['p',3],['p',1],['h',0],['r',2]]; break;
			case 1:
				if (['⮤','⮥'].includes(this.centerarrow)) {
					this.correct.push(['s',0])
				}
				else if (['⮡','⮣'].includes(this.centerarrow)) {
					this.correct.push(['s',1])
				}
				else if (['⮦','⮧'].includes(this.centerarrow)) {
					this.correct.push(['s',2])
				}
				else {
					this.correct.push(['s',3])
				}
				this.correct.push(['p','⮞'])
				this.correct.push(['p',2])
				this.correct.push(['h',4])
				this.correct.push(['w'])
				break;
			case 2:
				this.correct = [['p',0],['p',0],['p',0],['p',0],['p',0],['p',2],['p',2],['p',2],['p',2],['p',2],['h','⮟'],['r','⮝']]
				break;
			case 3:
				this.correct = [['h',0],['r',3],['h',1],['r',3]]
				break;
			case 4:
				this.correct = [['p',3],['p',1],['p',3],['p',1],['p',3],['p',1]]
				break;
			case 5://'⮝','⮞','⮟','⮜'
				this.correct = [['p','⮟'],['p','⮝'],['p','⮝'],['p','⮜']]
				break;
			case 6:
				this.correct = [['p',2],['p',3],['p',2],['p',3],['p',0]]
				break;
			case 7:
				this.correct = [['h',3],['r',1],['h',0],['r','⮜']]
				break;
		}
	}
	tick() {
		super.tick()
		this.isUp = ((this.target+this.defaultturn+100)%4)
		if (this.state != 'active') {
			this.turn = exphone(this.turn,this.target,10,0.02)
		}
		if (this.state == 'idle') {
				this.target = 0
		}
		else if (this.state == 'wind') {
				this.target = -8
		}
		if (this.fineRecieve.length > 0) {
			temp = this.fineRecieve[0]
			if (this.state == 'idle') {
				if (temp[0] == 'mid') {
					this.state = 'wind'
				}
			}
			else if (this.state == 'wind') {
				if (temp.length == 3 && this.turn != this.target) {
					level.addFail('Topsy Turvy')
					this.error = 30
					this.state = 'idle'
				}
				if (temp.length == 3 && this.turn == this.target) {
					this.state = 'active'
				}
			}
		}
		if (this.state == 'active') {
			if (this.timer == 60) {
				this.timer = 0
				this.target++
				this.updatePointing()
			}
			if (this.timer < this.table2.length) {
				this.turn += this.table2[this.timer]
				this.turn = roundi(this.turn,2)
			}
			this.timer++
			if (this.turn == 0) {
				if (this.correct[0][0] == 'w') {
					this.complete = true
					this.state = 'idle'
					this.target = 0
					this.timer = 60
				}
				else {
					this.yeowch()
				}
			}
			if (this.fineRecieve.length > 0 && this.fineRecieve[0][0] != 'mid') {
				temp = this.fineRecieve[0]
				if (this.correct[0][0] == 'p') {
					if (temp.length == 3) {
						if (typeof this.correct[0][1] == 'string') {
							if (temp[2] <= 8 && ['⮝','⮞','⮟','⮜'][(['⮝','⮞','⮟','⮜'].indexOf(this.labels[temp[0]])-this.isUp+8)%4] == this.correct[0][1]) {
								this.correct.shift()
							}
							else {
								this.yeowch()
							}
						}
						else {
							if (temp[2] <= 8 && (temp[0]-this.isUp+4)%4 == this.correct[0][1]) {
								this.correct.shift()
							}
							else {
								this.yeowch()
							}
						}
					}
				}
				else if (this.correct[0][0] == 's') {
					if (temp.length == 3) {
						if (temp[2] <= 8 && temp[0] == this.correct[0][1]) {
							this.correct.shift()
						}
						else {
							this.yeowch()
						}
					}
				}
				else if (this.correct[0][0] == 'h') {
					if (typeof this.correct[0][1] == 'string') {
							if (['⮝','⮞','⮟','⮜'][(['⮝','⮞','⮟','⮜'].indexOf(this.labels[temp[0]])-this.isUp+8)%4] == this.correct[0][1]) {
								this.correct.shift()
							}
							else {
								this.yeowch()
							}
						}
					else if (this.correct[0][1] == 4) {
						this.correct.shift()
					}
					else {
						if ((temp[0]-this.isUp+4)%4 == this.correct[0][1]) {
							this.correct.shift()
						}
						else if (temp.length == 3) {
							this.yeowch()
						}
					}
				}
				else if (this.correct[0][0] == 'r') {
					if (temp.length == 3) {
						if (typeof this.correct[0][1] == 'string') {
							if (['⮝','⮞','⮟','⮜'][(['⮝','⮞','⮟','⮜'].indexOf(this.labels[temp[0]])-this.isUp+8)%4] == this.correct[0][1]) {
								this.correct.shift()
							}
							else {
								this.yeowch()
							}
						}
						else {
							if ((temp[0]-this.isUp+4)%4 == this.correct[0][1]) {
								this.correct.shift()
							}
							else {
								this.yeowch()
							}
						}
					}
				}
				else if (this.correct[0][0] == 'w') {
					if (temp.length == 3) {
						this.yeowch()
					}
				}
				if (this.correct.length == 0) {
					this.complete = true
					this.state = 'idle'
					this.target = 0
					this.timer = 60
				}
			}
		}
		//if (compareValues(keys,[49,50,51,32])) {
		//	print(this.possi,this.correct)
		//}
	}
}

class Control extends Module {
	constructor(x,y,complete,error) {
		super(x,y,complete,error)
		new ModuleButton(this,'strike',0,60,120,80,16,0,false,['ADD\nSTRIKE',24])
		new ModuleButton(this,'remove',0,-60,120,80,16,0,false,['REMOVE\nSTRIKE',24],[100,240,100])
		this.complete = true
	}
	drawThis() {
		super.drawThis()
		push()
		translate(this.x,this.y)
		textSize(16)
		textAlign(CENTER,CENTER)
		fill(0)
		pop()
	}
	tick() {
		super.tick()
		if (this.recieve.includes('remove') && level.fails != 0) {
			level.addFail(null,-1)
		}
		if (this.recieve.includes('strike')) {
			level.addFail()
		}
	}
}

class ModuleButton {
	constructor(onmod,name,x,y,w,h,h2,shape=0,holdable=false,txt=null,rgb=[240,100,100]) {
		this.onmod = onmod
		this.name = name
		this.x = x
		this.y = y
		this.w = w
		this.h = h
		this.h2 = h2
		this.txt = txt
		this.shape = shape
		this.holdable = holdable
		this.inactive = false
		this.rgb = rgb
		this.yoff = 0
		this.onmod.inputs.push(this)
		this.presstime = 0
	}
	touchingMe() {
		if (turnx == 0 && turny == 0 && !this.inactive) {
			if (relativeMouseOn(this.onmod.x,this.onmod.y-this.h2,this.x,this.y,this.w,this.h) && this.shape == 0) {
				return true
			}
			else if (dist(mouseX-windowWidth/2,mouseY-windowHeight/2,this.x+this.onmod.x,this.y-this.h2+this.onmod.y+lookup[0]) <= this.w/2 && this.shape == 1) {
				return true
			}
			else {return false}
		}
	}
	setLabel(newLabel,size=this.txt[1]) {
		this.txt[0] = newLabel
		this.txt[1] = size
	}
	drawThis() {
		if (this.touchingMe()) {
			this.yoff = exphone(this.yoff,-1*this.h2/4,5,0.01)
			cursor(HAND)
		}
		else if (this.inactive) {}
		else {
			this.yoff = exphone(this.yoff,0,5,0.01)
		}
		push()
		translate(this.onmod.x,this.onmod.y)
		if (this.rgb.length == 6) {
			fill(this.rgb[3]-20,this.rgb[4]-20,this.rgb[5]-20)
		}
		else {fill(this.rgb[0]-20,this.rgb[1]-20,this.rgb[2]-20)}
		if (this.shape == 0) {
			rect(this.x,this.y,this.w,this.h)
			fill(this.rgb[0],this.rgb[1],this.rgb[2])
			rect(this.x,this.y-this.h2+this.yoff,this.w,this.h)
		}
		else {
			circle(this.x,this.y,this.w)
			beginShape()
			vertex(this.x-this.w/2,this.y)
			vertex(this.x-this.w/2,this.y-this.h2+this.yoff)
			vertex(this.x+this.w/2,this.y-this.h2+this.yoff)
			vertex(this.x+this.w/2,this.y)
			endShape()
			fill(this.rgb[0],this.rgb[1],this.rgb[2])
			circle(this.x,this.y-this.h2+this.yoff,this.w)
		}
		if (this.txt != null) {
			fill(40)
			textAlign(CENTER,CENTER)
			if (this.txt[1] != null)
			{textSize(this.txt[1])}
			if (this.txt.length == 3) {
				fill(this.txt[2])
			}
			text(this.txt[0],this.x,this.y-this.h2+this.yoff)
		}
	  pop()
	}
	ifPressed() {
		if (this.touchingMe() && mb && (this.holdable || mb == 2) && !this.inactive) {
			this.yoff = this.h2/10*9
			this.onmod.recieve.push(this.name)
			this.presstime += 1
			this.onmod.fineRecieve.push([this.name,this.presstime])
		}
		else {
			if (this.presstime != 0) {
				temp = this.presstime
				this.presstime = 0
				this.onmod.fineRecieve.push([this.name,this.presstime,temp])
			}
		}
	}
}