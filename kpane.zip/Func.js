function seg7(x,y,number=8) {
	push()
	translate(x,y)
	if ([0,2,3,5,6,7,8,9,'f'].includes(number)) {rect(x,y-32,24,8)}//top
	if ([2,3,4,5,6,8,9,'-','f'].includes(number)) {rect(x,y,24,8)}//mid
	if ([0,2,3,5,6,8,9].includes(number)) {rect(x,y+32,24,8)}//bot
	if ([0,4,5,6,8,9,'f'].includes(number)) {rect(x-16,y-16,8,24)}//top l
	if ([0,1,2,3,4,7,8,9].includes(number)) {rect(x+16,y-16,8,24)}//top r
	if ([0,2,6,8,'f'].includes(number)) {rect(x-16,y+16,8,24)}//bot l
	if ([0,1,3,4,5,6,7,8,9].includes(number)) {rect(x+16,y+16,8,24)}//bot r
	pop()
}

function roundi(value, decimals) {
  return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

function compareValues(a,b) {
	for (var i = 0; i < max(a.length,b.length); ++i) {
		if (a[i] != b[i] || a[i] == undefined || b[i] == undefined) {return false;}
	}
	return true;
}

vowels = 'AEIOU'
function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ012345678901234567890123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random()*charactersLength));
   }
   return result;
}

function exphone(inp,target,mult,snap) {
	if (inp < snap+target && inp > target-snap) {
		inp = target
	}
	else {
		inp += (target-inp)/mult
	}
	return inp
}

function touching(x1,y1,x2,y2,sx1,sy1,sx2,sy2) {
	if (x1+sx1/2 >= x2-sx2/2 && x1-sx1/2 <= x2+sx2/2 && y1+sy1/2 >= y2-sy2/2 && y1-sy1/2 <= y2+sy2/2) {
		return true
	}
	else {return false}
}

function relativeMouseOn(offx,offy,x2,y2,sx2,sy2) {
	x2 += offx
	y2 += offy
	y2 += lookup[0]
	if (mouseX-windowWidth/2 >= x2-sx2/2 && mouseX-windowWidth/2 <= x2+sx2/2 && mouseY-windowHeight/2 >= y2-sy2/2 && mouseY-windowHeight/2 <= y2+sy2/2) {
		return true
	}
	else {return false}
}

//doodads
function doodad(type,x,y,extrainfo='') { //sides budget: 700
	push()
	translate(x,y)
	if (type == 'd battery') {//cost: 350
		translate(0,87.5)
		fill(120,90,90)
		rect(0,0,600,300)
		fill(20)
		rect(0,0,450,260)
		fill(150)
		rect(0,125,300,10)
		rect(0,-125,90,10)
		fill(50,50,60)
		noStroke()
		rect(0,0,375,240)
		fill(80,80,100)
		rect(100,0,175,240)
	}
	else if (type == 'serial') {//cost: 350
		scale(4,1)
		translate(0,87.5)
		fill(220)
		rect(0,0,80,300)
		rotate(PI/-2)
		fill(40)
		textSize(35)
	  scale(0.8,1)
		text('SERIAL: '+level.serial,-170,10)
	}
	else if (type == 'li cell') {//cost: 350
		translate(0,87.5)
		fill(120,50,50)
		rect(0,0,600,300)
		fill(20)
		rect(0,0,450,260)
		noStroke()
		fill(30,170,30)
		rect(0,-120,375,10,15,15,0,0)
		rect(0,120,375,10,0,0,15,15)
		fill(0,200,0)
		rect(0,0,375,240)
		fill(0,150,0)
		rect(138.5,0,100,240)
		rect(40,0,40,240)
	}
	else if (type == 'aa batteries') { //cost: 125
		fill(120,90,90)
		rect(0,0,550,125)
		fill(20)
		rect(0,0,450,100)
		fill(150)
		rect(200,25,30,30)
		rect(-200,25,30,10)
		if (extrainfo != '1') {
			rect(200,-25,30,30)
			rect(-200,-25,30,10)
		}
		fill(50,50,60)
		noStroke()
		rect(0,25,400,40)
		if (extrainfo != '1') {
		rect(0,-25,400,40)
		}
		fill(80,80,100)
		rect(0,40,400,10)
		if (extrainfo != '1') {
		rect(0,-10,400,10)
		}
	}
	else if (type == 'gamecube port') { //cost: 125
		scale(4,1)
		fill(70)
		noStroke()
		circle(0,0,75)
		fill(100)
		circle(0,0,50)
		fill(70)
		rect(0,-21,40,10)
		fill(200,200,0)
		rect(0,0,5,19)
		rect(10,0,5,19)
		rect(-10,0,5,19)
		fill(70)
		rect(0,0,30,15)
	}
	else if (type == 'midi port') { //cost: 125
		scale(4,1)
		fill(40)
		noStroke()
		circle(0,0,75)
		fill(100)
		circle(0,0,60)
		fill(40)
		rect(0,-24,24,15)
		strokeWeight(2)
		stroke(200)
		line(-9,7,-12,15)
		line(-13,-4,-17,4)
		line(0,11,0,19)
		line(9,7,12,15)
		line(13,-4,17,4)
		noStroke()
		fill(40)
		circle(15,0,7)
		circle(11,11,7)
		circle(0,15,7)
		circle(-11,11,7)
		circle(-15,0,7)
	}
	else if (type == 'parallel port') {
		translate(0,87.5)
		scale(4,1)
		fill(150,120,120)
	  beginShape()
		vertex(-20,120)
		vertex(-20,-120)
		quadraticVertex(-20,-140,0,-130)
		quadraticVertex(20,-120,20,-110)
		vertex(20,110)
		quadraticVertex(20,120,0,130)
		quadraticVertex(-20,140,-20,120)
		endShape()
		fill(60)
		for (i=0; i < 12; i++) {
			circle(-8,120-20*i,8)
			circle(8,110-20*i,8)
		}
		circle(-8,-120,8)
		fill(150)
		circle(0,150,18)
		circle(0,-150,18)
	}
	pop()
}